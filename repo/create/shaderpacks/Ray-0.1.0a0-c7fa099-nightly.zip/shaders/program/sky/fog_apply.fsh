/*
 * composite19: フォグ / VL の適用 (colortex12 をバイラテラルにアップサンプルして colortex0 に合成)
 * 順番 (遠い方から): 地形 -> 空中遠近 -> 描画距離端のフォグ -> カメラ側の媒質 (高さフォグ / 水 / 溶岩 / 粉雪)
 * -> 画面空間の光芒 (composite12-14 の結果) -> 手前の雲 (雲より上にいる時。光芒は雲の下の空気の光なので雲に隠れる)
 * -> 雲の中の霧 (カメラが雲の層の中の時) -> 手持ち光源が霧を照らす光 (点光源の内散乱を解析積分) -> 盲目・暗闇
 * 光芒をここで足すのは、フォグ・手前の雲・雲の中の霧・盲目の順番に自然に乗せ、全画面の読み書きを増やさないため
 * sky モジュール (lib/sky)
 */
//@include "/lib/common/common.glsl"
//@include "/lib/buffers/block_data.glsl"
//@include "/lib/common/gbuffer.glsl"
//@include "/lib/common/phase.glsl"
//@include "/lib/common/water.glsl"
//@include "/lib/sky/sky.glsl"
//@include "/lib/sky/godrays.glsl"
//@include "/lib/light/light.glsl"
// BEGIN GENERATED includes (tools/gen_includes.py)
#include "/lib/settings/look.glsl"
#include "/lib/settings/light.glsl"
#include "/lib/settings/surface.glsl"
#include "/lib/settings/sky.glsl"
#include "/lib/settings/post.glsl"
#include "/lib/settings/internal.glsl"
#include "/lib/settings/bool_refs.glsl"
#include "/lib/settings.glsl"
#include "/lib/common/dimension.glsl"
#include "/lib/common/constants.glsl"
#include "/lib/common/uniforms.glsl"
#include "/lib/common/samplers.glsl"
#include "/lib/common/math.glsl"
#include "/lib/common/shading_types.glsl"
#include "/lib/common/common.glsl"
#include "/lib/buffers/block_data.glsl"
#include "/lib/common/color.glsl"
#include "/lib/common/encoding.glsl"
#include "/lib/common/gbuffer.glsl"
#include "/lib/common/phase.glsl"
#include "/lib/common/noise.glsl"
#include "/lib/common/transforms.glsl"
#include "/lib/buffers/frame_data.glsl"
#include "/lib/common/water_waves.glsl"
#include "/lib/common/water_glitter.glsl"
#include "/lib/common/water_lod.glsl"
#include "/lib/common/water_normal.glsl"
#include "/lib/common/water.glsl"
#include "/lib/sky/sh.glsl"
#include "/lib/buffers/images.glsl"
#include "/lib/sky/atmosphere.glsl"
#include "/lib/common/celestial_shape.glsl"
#include "/lib/sky/celestial.glsl"
#include "/lib/common/look_presets.glsl"
#include "/lib/common/frame_offset.glsl"
#include "/lib/sky/cloud_styles.glsl"
#include "/lib/sky/clouds.glsl"
#include "/lib/sky/sky_color.glsl"
#include "/lib/sky/fog_template.glsl"
#include "/lib/sky/climate.glsl"
#include "/lib/sky/fog_styles.glsl"
#include "/lib/sky/fog.glsl"
#include "/lib/sky/sky.glsl"
#include "/lib/sky/godrays.glsl"
#include "/lib/buffers/light_bins.glsl"
#include "/lib/light/light_bins.glsl"
#include "/lib/ids/block_ids.glsl"
#include "/lib/ids/light_ids.glsl"
#include "/lib/light/light_def.glsl"
#include "/lib/light/light_table_data.glsl"
#include "/lib/light/light_table.glsl"
#include "/lib/light/block_data.glsl"
#include "/lib/common/voxel_space.glsl"
#include "/lib/ids/entity_ids.glsl"
#include "/lib/ids/material_ids.glsl"
#include "/lib/ids/id_decode.glsl"
#include "/lib/light/voxel_read.glsl"
#include "/lib/light/voxel.glsl"
#include "/lib/light/floodfill.glsl"
#include "/lib/buffers/entity_tris.glsl"
#include "/lib/light/entity_tri.glsl"
#include "/lib/light/trace.glsl"
#include "/lib/buffers/global_lights.glsl"
#include "/lib/light/light_select.glsl"
#include "/lib/light/entity_light.glsl"
#include "/lib/light/hand_pose.glsl"
#include "/lib/light/hand_light.glsl"
#include "/lib/light/blocklight.glsl"
#include "/lib/light/light.glsl"
// END GENERATED includes

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

// アップサンプルの深度の重み (相対深度差に対する鋭さ)
const float VL_UPSAMPLE_DEPTH_SHARPNESS = 20.0;
const float BLINDNESS_CLEAR_DIST = 2.0;
const float WATER_BORDER_FOG = 0.25; // 水面に掛ける描画距離端のフォグの割合
/*
 * 水中の内散乱の倍率。単散乱そのままだと水面近くの水が空の光で明るく光り、水面越しの空・地形との差が無い
 * 白っぽい一面の青になった。露出を下げるだけでは水面の明るさも一緒に沈むので、
 * 内散乱を弱めて深い所を暗く、水面 (スネルの窓) を相対的に明るく残す
 */
const float WATER_FOG_INSCATTER = 0.5;

vec4 fetchVolumetrics(ivec2 lowTexel) {
    lowTexel = clamp(lowTexel, ivec2(0), vlLowResSize() - 1);
    return vlWritesColortex12() ? texelFetch(colortex12, lowTexel, 0) : texelFetch(fogHistorySampler, lowTexel, 0);
}

// 深度を見たバイリニア (低解像度の 4 点のうち、深度の近い点だけを使う)
vec4 upsampleVolumetrics(ivec2 texel, float linearDepth) {
    vec2 lowPos = (vec2(texel) - float(VL_RES / 2)) / float(VL_RES);
    ivec2 base = ivec2(floor(lowPos));
    vec2 f = lowPos - vec2(base);
    vec4 sum = vec4(0.0);
    float weightSum = 0.0;
    vec4 nearest = vec4(0.0, 0.0, 0.0, 1.0);
    float nearestDiff = 1e9;
    for (int i = 0; i < 4; i++) {
        ivec2 o = ivec2(i & 1, i >> 1);
        ivec2 q = clamp(base + o, ivec2(0), vlLowResSize() - 1);
        float sampleDepth = linearizeDepth(fixHandDepth(texelFetch(depthtex0, vlSampleTexel(q), 0).r));
        float diff = abs(sampleDepth - linearDepth) / max(linearDepth, 0.1);
        vec2 bw = mix(1.0 - f, f, vec2(o));
        float w = bw.x * bw.y * exp(-diff * VL_UPSAMPLE_DEPTH_SHARPNESS);
        vec4 s = fetchVolumetrics(q);
        sum += s * w;
        weightSum += w;
        if (diff < nearestDiff) { nearestDiff = diff; nearest = s; }
    }
    return weightSum > 1e-4 ? sum / weightSum : nearest;
}

/*
 * 水中の手持ち光源の内散乱。光源 -> 散乱点 -> カメラの経路で水に弱まるので atan の閉じた形が使えない
 * t - t0 = a tan(theta) と置くと 1 / ((t - t0)^2 + a^2) dt = dtheta / a になるので、角度を等分した中点で数値積分する
 * (equiangular sampling, Kulla & Fajardo 2012 の考え方。光源の近くほど細かく区切られる)
 */
const int HAND_GLOW_WATER_STEPS = 6;

// t0: 視線上で光源に最も近い点までの距離, a = sqrt(h^2 + 1), h2: 光源と視線の距離の 2 乗, ext: 消散係数
vec3 handLightGlowWater(float t0, float a, float h2, float dist, vec3 ext) {
    float thA = atan(-t0 / a);
    float thB = atan((dist - t0) / a);
    float dTh = (thB - thA) / float(HAND_GLOW_WATER_STEPS);
    vec3 sum = vec3(0.0);
    for (int i = 0; i < HAND_GLOW_WATER_STEPS; i++) {
        float s = a * tan(thA + (float(i) + 0.5) * dTh);
        sum += exp(-ext * (t0 + s + sqrt(s * s + h2)));
    }
    return sum * (dTh / a);
}

/*
 * 点光源 (手持ち) からの内散乱を視線に沿って解析積分 (逆二乗 1 / (d^2 + 1) の積分は atan で閉じる)
 * 影は無視する (手の周りの数ブロックの淡い光の暈なので見た目に差が出ない)。水中だけ水の吸収と散乱で弱める
 */
vec3 handLightGlow(vec3 dir, float dist, vec3 scatterCoeff, bool inWater) {
    vec3 glow = vec3(0.0);
#ifdef HAND_LIGHT
    for (int hand = 0; hand < 2; hand++) {
        bool mainHand = hand == 0;
        int level = mainHand ? heldBlockLightValue : heldBlockLightValue2;
        if (level <= 0) continue;
        HandLight h = handLightAt(mainHand);
        vec3 intensity = h.emission * HAND_LIGHT_BRIGHTNESS;
        vec3 lightPos = h.handPos;
        float t0 = dot(lightPos, dir);
        float h2 = max(dot(lightPos, lightPos) - t0 * t0, 0.0);
        float a = sqrt(h2 + 1.0);
        if (inWater) {
            glow += intensity * handLightGlowWater(t0, a, h2, dist, waterExtinction());
        } else {
            glow += intensity * ((atan((dist - t0) / a) - atan(-t0 / a)) / a);
        }
    }
#endif
    return glow * scatterCoeff * PHASE_ISOTROPIC;
}

void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);
    vec4 sceneIn = texelFetch(colortex0, texel, 0);
    vec3 color = sceneIn.rgb;
    /*
     * 鏡面の白飛び分 (composite2 / deferred30 が a = 1 + 輝度の割合で書く)。TAA (composite20) が近傍の箱で潰さず後から足すので、
     * フォグで減る分 (透過率) を掛けた輝度を追い、最後に割合へ戻して渡す
     */
    float sparkle = saturate(sceneIn.a - 1.0) * luminance(color);
    /*
     * 溶岩の発光も同じ仕組みで追い、a = -割合で渡す (composite23 がブルームの元でだけ明るくする)
     * 白飛び分の無い画素は a = 0 (TAA の sparkleShare はどちらも 0)
     */
    bool lavaGlow = sparkle <= 0.0 && readMaterialId(texel) == MAT_LAVA;
    if (lavaGlow) sparkle = luminance(color);
    float depth = texelFetch(depthtex0, texel, 0).r;
    bool isSky = depth >= 1.0;
    float fixedDepth = isSky ? 1.0 : fixHandDepth(depth);
    vec3 playerPos = screenToPlayer(vec3(texcoord, fixedDepth));
    vec3 dir = normalize(playerPos);
    float dist = isSky ? fogRenderDistance() : length(playerPos);
    // 地形の手前の雲 (空気中のみ)。フォグの後に重ねる
    vec4 frontClouds = vec4(0.0, 0.0, 0.0, 1.0);

    // 遠景 (空気中のみ。水中・溶岩の中からは遠景が見えないので媒質のフォグだけで十分)
    if (!isSky && isEyeInWater == 0) {
        color = applyAerialPerspective(color, playerPos);
        // 空中遠近の透過率 (加わる空の色を除いた分)。白飛び分のある画素だけ求める
        if (sparkle > 0.0) sparkle *= luminance(applyAerialPerspective(vec3(1.0), playerPos) - applyAerialPerspective(vec3(0.0), playerPos));
        float borderFog = getBorderFog(playerPos);
        // 水面は描画距離の外へ続く平面で、端の色は地平線の空の映り込みとほぼ同じ。端のフォグで地平線の色へ溶かすと
        // 遠くの水面の雲や島の映り込みが消え、水平線の手前が白い帯になっていた
        vec3 nT; vec2 lmT; int matT;
        decodeTranslucentData(texelFetch(colortex5, texel, 0), nT, lmT, matT);
        if (matT == MAT_WATER && depth < texelFetch(depthtex1, texel, 0).r) borderFog *= WATER_BORDER_FOG;
        color = mix(color, getBorderFogColor(dir), borderFog);
        sparkle *= 1.0 - borderFog;
#if CLOUDS >= 2 && defined HAS_SKY
        // 雲の下面より上にいる時だけ、地形の手前の雲を求める (deferred20 は地形までの区間だけを積分している)。
        // 重ねるのは高さフォグの後 (雲の下のもやと霧の層は雲の向こうにあり、雲の上に塗られないように)
        if (cameraPosition.y > cloudLowestBase()) {
            frontClouds = getCloudLayer(texel);
            // 半透明が手前にある画素の雲は奥の地形 (空) まで積分してあるので、半透明までの分だけに割り引く
            float depthOpaque = texelFetch(depthtex1, texel, 0).r;
            if (depth < depthOpaque) {
                float backDist = depthOpaque >= 1.0 ? CLOUD_RAY_FAR : length(screenToPlayer(vec3(texcoord, fixHandDepth(depthOpaque))));
                frontClouds = cloudFrontPart(frontClouds, dir, dist, backDist);
            }
        }
#endif
    }

    vec3 scatterCoeff;
    if (isEyeInWater == 1) {
        vec3 extinction = waterExtinction();
        vec3 transmittance = exp(-extinction * dist);
#ifdef VL
        vec3 inscatter = upsampleVolumetrics(texel, linearizeDepth(fixedDepth)).rgb;
#else
        vec3 ambient = shEvalIrradiance(vec3(0.0, 1.0, 0.0)) * 0.5 * RCP_PI * (1.0 - getCaveFactor() * 0.8) + getCelestialLight().irradiance * 0.05;
        vec3 inscatter = ambient * waterScattering() / extinction * (1.0 - transmittance) * exp(-extinction * 3.0);
#endif
        color = color * transmittance + inscatter * WATER_FOG_INSCATTER;
        // 媒質の内散乱は白飛び分に入れない (掛け忘れると割合が 1 に張り付き、画素全体が TAA を通らなくなる)
        sparkle *= luminance(transmittance);
        scatterCoeff = waterScattering();
    } else if (isEyeInWater == 2) {
        vec3 transmittance = exp(-FOG_LAVA_EXTINCTION * dist);
        color = color * transmittance + FOG_LAVA_RADIANCE * (1.0 - transmittance);
        sparkle *= luminance(transmittance);
        scatterCoeff = vec3(0.0);
    } else if (isEyeInWater == 3) {
        vec3 transmittance = exp(-FOG_POWDER_SNOW_EXTINCTION * dist);
        vec3 snowLight = (shEvalIrradiance(vec3(0.0, 1.0, 0.0)) + getCelestialLight().irradiance * 0.3) * RCP_PI * 0.8 + MIN_AMBIENT;
        color = color * transmittance + snowLight * (1.0 - transmittance);
        sparkle *= luminance(transmittance);
        scatterCoeff = vec3(0.0);
    } else {
#ifdef VL
        vec4 fog = upsampleVolumetrics(texel, linearizeDepth(fixedDepth));
#else
        float outdoor = 1.0 - getCaveFactor();
    #ifdef CAVE_LEAK_PREVENTION
        float sunVisibility = outdoor * farSunShade(dir);
    #else
        float sunVisibility = outdoor;
    #endif
        sunVisibility *= farSunHiddenShade(dir);
        vec4 fog = fogAnalyticSegment(dir, 0.0, dist, fogLightingSetup(dir), sunVisibility, max(outdoor, 0.05));
#endif
        color = color * fog.a + fog.rgb;
        sparkle *= fog.a;
#if defined HAS_SKY
        vec2 localDensity = fogDensityAt(vec3(0.0), fogMedium());
    #ifdef GODRAYS
        if (!isHandDepth(depth)) color += evalGodraysRadiance(texcoord, isSky, dist, localDensity.x + localDensity.y);
    #endif
#endif
        color = color * frontClouds.a + frontClouds.rgb;
        sparkle *= frontClouds.a;
#ifdef CLOUD_INTERIOR
        // カメラが雲の中: 層を出るまで一様な霧として掛ける。手持ちの物・自分の体 (手の深度) には掛けない
        // 半透明の向こうの背景の分 (半透明から奥の不透明面まで) は translucent_composite が先に掛けてあり、ここは手前の半透明までの区間
        if (!isHandDepth(depth)) {
            vec4 interiorFog = cloudInteriorFog(dir, 0.0, dist);
            color = color * interiorFog.a + interiorFog.rgb;
            sparkle *= interiorFog.a;
        }
#endif
#if defined HAS_SKY
        scatterCoeff = vec3((localDensity.x + localDensity.y) * FOG_ALBEDO);
#elif defined WORLD_END
        scatterCoeff = vec3(END_FOG_EXTINCTION * END_FOG_DENSITY);
#else
        scatterCoeff = vec3(netherFogExtinction());
#endif
    }

    if (maxOf(scatterCoeff) > 0.0) color += handLightGlow(dir, min(dist, 32.0), scatterCoeff, isEyeInWater == 1);

    // 盲目・暗闇: 近く以外を黒へ (バニラと同じく視界を奪う効果)
    float blindFog = max(blindness, darknessFactor * (0.6 + 0.4 * darknessLightFactor));
    if (blindFog > 0.0) {
        float blindT = mix(1.0, exp(-BLINDNESS_FOG_EXTINCTION * max(dist - BLINDNESS_CLEAR_DIST, 0.0)), blindFog);
        color *= blindT;
        sparkle *= blindT;
    }

    float share = saturate(sparkle / max(luminance(color), 1e-6));
    outColor = vec4(color, lavaGlow ? -share : (share > 0.0 ? 1.0 + share : 0.0));
}
