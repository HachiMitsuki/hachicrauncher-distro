/*
 * deferred30: 不透明面のシェーディング (全モジュールの光をここで合成) と空の描画
 *   光は surface の gatherSurfaceLights (lib/surface/surface_lights.glsl) で集め、BRDF・AO・溶岩・水たまり・SSS の減衰をここで掛ける
 *   太陽/月: 影 x 雲影、空の環境光: SH x スカイライト x AO
 *     (SSGI / ボクセル RT では GI のレイが向きと遮蔽込みで空の光を運び、これを置き換える。GI_TRACES_SKY)
 *   ブロックライト: 拡散 (+ 鏡面)、手持ち光源、GI
 * surface モジュール (lib/surface)
 *
 * 環境光の鏡面 (反射バッファ・空) はここでは足さず composite2 で足す (反射パスが colortex0 のこの結果を映すため)
 * 合成の考え方
 *   太陽: PCSS の影 (色付き・水底のコースティクス込み) x POM の自己影 x 接触影 x 雲影。影マップの外はスカイライトで近似
 *   SSS: 影のブロッカー探索で得た厚みで減衰させた太陽光を裏面透過として足す。手持ち光源の透過も含め、設定 SSS が無ければ外す
 *   AO: 空の照度には多重バウンス AO を全部、ブロックライトには半分 (光源シャドウで既に遮蔽されているため)、GI はバニラ AO だけ
 */
//@include "/lib/common/common.glsl"
//@include "/lib/common/exposure.glsl"
//@include "/lib/common/jitter.glsl"
//@include "/lib/common/specular_sparkle.glsl"
//@include "/lib/surface/surface.glsl"
//@include "/lib/sky/sky.glsl"
//@include "/lib/light/light.glsl"
//@include "/lib/surface/surface_lights.glsl"
// BEGIN GENERATED includes (tools/gen_includes.py)
#include "/lib/settings/look.glsl"
#include "/lib/settings/light.glsl"
#include "/lib/settings/surface.glsl"
#include "/lib/settings/sky.glsl"
#include "/lib/settings/post.glsl"
#include "/lib/settings/internal.glsl"
#include "/lib/settings/bool_refs.glsl"
#include "/lib/settings.glsl"
#include "/lib/common/dimension.glsl"
#include "/lib/common/constants.glsl"
#include "/lib/common/uniforms.glsl"
#include "/lib/common/samplers.glsl"
#include "/lib/common/math.glsl"
#include "/lib/common/shading_types.glsl"
#include "/lib/common/common.glsl"
#include "/lib/buffers/frame_data.glsl"
#include "/lib/common/exposure.glsl"
#include "/lib/common/jitter.glsl"
#include "/lib/common/color.glsl"
#include "/lib/common/specular_sparkle.glsl"
#include "/lib/common/encoding.glsl"
#include "/lib/common/gbuffer.glsl"
#include "/lib/ids/block_ids.glsl"
#include "/lib/ids/material_ids.glsl"
#include "/lib/surface/material.glsl"
#include "/lib/surface/brdf.glsl"
#include "/lib/common/frame_offset.glsl"
#include "/lib/common/look_presets.glsl"
#include "/lib/common/voxel_space.glsl"
#include "/lib/surface/gi.glsl"
#include "/lib/common/noise.glsl"
#include "/lib/common/transforms.glsl"
#include "/lib/common/water_waves.glsl"
#include "/lib/common/water_glitter.glsl"
#include "/lib/common/water_lod.glsl"
#include "/lib/common/water_normal.glsl"
#include "/lib/common/water.glsl"
#include "/lib/common/shadow_space.glsl"
#include "/lib/common/shadow_volume.glsl"
#include "/lib/surface/sun_shadow.glsl"
#include "/lib/surface/waving.glsl"
#include "/lib/surface/surface.glsl"
#include "/lib/sky/sh.glsl"
#include "/lib/common/phase.glsl"
#include "/lib/buffers/images.glsl"
#include "/lib/sky/atmosphere.glsl"
#include "/lib/common/celestial_shape.glsl"
#include "/lib/sky/celestial.glsl"
#include "/lib/sky/cloud_styles.glsl"
#include "/lib/sky/clouds.glsl"
#include "/lib/sky/sky_color.glsl"
#include "/lib/sky/fog_template.glsl"
#include "/lib/sky/climate.glsl"
#include "/lib/sky/fog_styles.glsl"
#include "/lib/sky/fog.glsl"
#include "/lib/sky/sky.glsl"
#include "/lib/buffers/light_bins.glsl"
#include "/lib/light/light_bins.glsl"
#include "/lib/buffers/block_data.glsl"
#include "/lib/ids/light_ids.glsl"
#include "/lib/light/light_def.glsl"
#include "/lib/light/light_table_data.glsl"
#include "/lib/light/light_table.glsl"
#include "/lib/light/block_data.glsl"
#include "/lib/ids/entity_ids.glsl"
#include "/lib/ids/id_decode.glsl"
#include "/lib/light/voxel_read.glsl"
#include "/lib/light/voxel.glsl"
#include "/lib/light/floodfill.glsl"
#include "/lib/buffers/entity_tris.glsl"
#include "/lib/light/entity_tri.glsl"
#include "/lib/light/trace.glsl"
#include "/lib/buffers/global_lights.glsl"
#include "/lib/light/light_select.glsl"
#include "/lib/light/entity_light.glsl"
#include "/lib/light/hand_pose.glsl"
#include "/lib/light/hand_light.glsl"
#include "/lib/light/blocklight.glsl"
#include "/lib/light/light.glsl"
#include "/lib/surface/surface_lights.glsl"
// END GENERATED includes

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

const float AO_BLOCKLIGHT_WEIGHT = 0.5;
// GI が空の光を運ぶ時 (GI_TRACES_SKY): テクスチャ法線の凹凸の戻し方の範囲、GTAO を掛ける割合
const float GI_NORMAL_DETAIL_MIN = 0.5;
const float GI_NORMAL_DETAIL_MAX = 1.5;
const float GI_SKY_GTAO_WEIGHT = 0.5;
// SSS の減衰 (1/ブロック, sss = 1 の時)。葉 1 枚 (~0.1 ブロック) は通し、葉ブロック 1 個分でかなり暗くなる
const float SSS_DENSITY = 2.5;
// 溶岩の面が受けるブロックライト・GI の割合
const float LAVA_RECEIVED_LIGHT = 0.15;
/*
 * 溶岩の見た目の輝度。他の発光と同じ g.emission (0.12-0.3) x 露出の -0.45 乗では、暗い洞窟で
 * 溶岩に照らされた壁と同じ明るさになり、光って見えない。周りへの光 (光源・floodfill・GI の g.emission) は変えず、見た目の輝度だけ別に持つ
 *   橙の地 (テクスチャの線形輝度 LAVA_BODY_ALBEDO) を LAVA_LUMINANCE にし、黄色い筋は輝度の比の LAVA_PATTERN_CONTRAST 乗で明るくする
 *   画面に溶岩が多いと露出が下がって橙の地が露出後 0.3-0.5 に収まる。溶岩が小さく露出が高い時は、露出後の地の明るさを
 *   LAVA_EXPOSED_MAX で頭打ちにする (白く飛ばさない)。色は final の溶岩専用のトーンマップで橙のまま残す
 * 頭打ちのままではブルームの滲みが出ず光って見えないので、滲みはブルームの元でだけ溶岩を明るくして出す
 * (composite23 の LAVA_BLOOM_GAIN)。上限 1.2 (溶岩のトーンマップは白へ抜け始めが高いので、橙の地は淡くならない)
 * ここ (シーンの HDR) を上げると露出の測光が下がって周りの壁が暗くなり、ブルームも一緒に変わるので、
 * 見た目の明るさは final で表示の段だけ上げる (設定 LAVA_BRIGHTNESS)
 */
const float LAVA_LUMINANCE = 0.8;
const float LAVA_BODY_ALBEDO = 0.175;
const float LAVA_PATTERN_CONTRAST = 2.6;
const float LAVA_EXPOSED_MAX = 1.2;

#ifdef EMISSION_GLARE
/*
 * EMISSION_GLARE: 光源ブロックの発光部分の輝度の倍率 (露出に応じて下げる getVisibleEmissionLuminance の前の値に掛ける)
 * 1 では昼の炎の芯が露出後 1 前後で AgX の白に届かず、光って見えない。4 で昼は芯が白く飛び、露出の上がる夜・洞窟では芯が大きく飛ぶ。
 * 8 以上は夜のグロウストーンが模様の消えた白い板になる。露出の測光は上位 8% を除くので、小さな光源は露出を下げない
 * ブロック全体が光る光源 (グロウストーンなど) は発光の斑が画面の広い面積を占め、同じ倍率では全体が白い塊になって模様が消えるので抑える
 */
const float EMISSION_POINT_GAIN = 4.0;
const float EMISSION_AREA_GAIN = 1.5;
#else
const float EMISSION_POINT_GAIN = 1.0;
const float EMISSION_AREA_GAIN = 1.0;
#endif

// 光源の種類ごとの見た目の明るさ (設定 EMISSION_*_BRIGHTNESS) x 倍率。種類は光源の表のフラグ。表に種類のない光源は倍率だけ
float emissionKindGain(uint flags) {
    if ((flags & LIGHT_FLAG_KIND_TORCH) != 0u) return EMISSION_TORCH_BRIGHTNESS * EMISSION_POINT_GAIN;
    if ((flags & LIGHT_FLAG_KIND_FIRE) != 0u) return EMISSION_FIRE_BRIGHTNESS * EMISSION_POINT_GAIN;
    if ((flags & LIGHT_FLAG_KIND_LANTERN) != 0u) return EMISSION_LANTERN_BRIGHTNESS * EMISSION_POINT_GAIN;
    if ((flags & LIGHT_FLAG_KIND_BEACON) != 0u) return EMISSION_BEACON_BRIGHTNESS * EMISSION_POINT_GAIN;
    if ((flags & LIGHT_FLAG_OCCLUDES) != 0u) return EMISSION_BLOCK_BRIGHTNESS * EMISSION_AREA_GAIN;
    return EMISSION_POINT_GAIN;
}

// 面の位置から法線の逆向き (と順向き) へ入れて光源のセルを読む距離。深度の誤差で隣のセルを読まず、セルの縁にある炎も拾う
const float EMISSION_KIND_INSET = 0.25;

float emissionGain(vec3 playerPos, vec3 geoNormal, int materialId, bool hand) {
    uint flags = 0u;
    if (materialId == MAT_BEACON_BEAM) {
        flags = LIGHT_FLAG_KIND_BEACON;
    } else if (hand) {
        // 持っている光源 (両手のときは利き手)
        flags = getHandLightDef(heldBlockLightValue > 0 ? heldItemId : heldItemId2).info.x;
    } else {
        for (int i = 0; i < 2; i++) {
            ivec3 cell = ivec3(floor(playerToVoxel(playerPos + geoNormal * (i == 0 ? -EMISSION_KIND_INSET : EMISSION_KIND_INSET))));
            if (!isInVoxelVolume(cell)) break;
            int light = getBlockLightIndex(fetchVoxelBlockId(cell));
            if (light != LIGHT_NONE) {
                flags = getLightDef(light).info.x;
                break;
            }
        }
    }
    return emissionKindGain(flags);
}

vec3 lavaRadiance(vec3 albedo) {
    float lum = max(luminance(albedo), 1e-4);
    float pattern = pow(lum / LAVA_BODY_ALBEDO, LAVA_PATTERN_CONTRAST);
    float exposed = LAVA_LUMINANCE * getExposure();
    float limit = inversesqrt(1.0 + sqr(exposed / LAVA_EXPOSED_MAX));
    return albedo / lum * (pattern * LAVA_LUMINANCE * limit);
}

/*
 * 直接光 1 つ。拡散を返し、鏡面は specSum に足す (白飛び分は集めた鏡面の合計から求める)
 * slopeVar > 0 (水たまり): 鏡面の粗さを傾きの分散の分だけ広げる (雨粒の跳ねと画素より細かい波紋)
 * specVis: 光の円盤の見え方 (太陽は雨雲の層の下で隠れる。他の光は 1)。拡散には掛けない
 */
vec3 directLight(Material m, vec3 N, vec3 V, LightSample L, float slopeVar, float specVis, float discScale, float strength, inout vec3 specSum) {
    vec3 spec;
    vec3 diffuse = evalDirectLight(m, N, V, L, discScale, spec);
    if (slopeVar > 0.0) {
        Material rough = m;
        rough.roughness = sqrt(sqr(m.roughness) + slopeVar);
        spec = evalDirectSpecular(rough, N, V, L, discScale);
    }
    specSum += spec * (specVis * strength);
    return diffuse;
}

void directSpecular(Material m, vec3 N, vec3 V, LightSample L, float slopeVar, float strength, inout vec3 specSum) {
    Material rough = m;
    rough.roughness = sqrt(sqr(m.roughness) + slopeVar);
    specSum += evalDirectSpecular(rough, N, V, L) * strength;
}

/*
 * ブロックのテクスチャの 1 テクセル (1/16 ブロック) が 1 画素より小さくなる距離では、鏡面の白飛び分を TAA の外へ出さない
 * 自動法線はテクセルの中で一定で、テクセルの境目の照り返しが 1 画素未満になると、TAA を通さない分がジッターで
 * 毎フレーム当たり外れしてちらつく (gbuffers_solid.fsh の鏡面 AA を入れない理由と同じ)。水たまりは滑らかな面なので常に出す
 */
const vec2 SPARKLE_TEXEL_PX = vec2(0.3, 0.7);  // 1 テクセルの画素数がこの範囲で 0 -> 1
const float SPARKLE_TEXEL_SIZE = 1.0 / 16.0;

void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);
    float depth = texelFetch(depthtex0, texel, 0).r;

    if (depth >= 1.0) {
        vec3 dir = normalize(viewToPlayerDir(screenToView(vec3(texcoord, 1.0))));
        vec3 sky = renderSky(dir, texelFetch(colortex0, texel, 0).rgb);
        vec4 clouds = getCloudLayer(texel);
        outColor = vec4(sky * clouds.a + clouds.rgb, 1.0);
        return;
    }

    GBufferData g = readGBuffer(texel);
    Material m = decodeMaterial(g);
    bool hand = isHandDepth(depth);
    // 画面空間の接触影は深度バッファと同じくジッター込みの位置から辿る
    vec3 viewPos = screenToView(vec3(texcoord, fixHandDepth(depth)));
    /*
     * 光と影はジッターを戻した面の上の点で求める。texcoord のまま戻すと面から最大で半画素ぶん浮くか沈み、
     * 影マップの解像度が高い足元では深度の余裕より大きくなって、ジッターの向きによっては足元の円の中の日向が
     * 自分の影になっていた (動いて TAA の履歴が効かない時にだけ 1 フレーム見える)
     */
    vec3 playerPos = viewToPlayer(screenToView(vec3(removeTaaJitter(texcoord), fixHandDepth(depth))));
    vec3 V = -normalize(playerPos);
    float dither = interleavedGradientNoise(gl_FragCoord.xy, frameCounter);
    SurfacePoint sp = surfacePoint(playerPos, g.normal);
    sp.viewPos = viewPos;
    sp.geoNormal = g.geoNormal;
    sp.lightmap = g.lightmap;
    sp.texel = texel;
    sp.dither = dither;
    sp.hand = hand;
    vec4 indirect = gatherSurfaceLights(sp, SL_SUN_NONE, SL_BLOCK_NONE, SL_GI).indirect;
    float pomShadow, puddle;
    readSurfaceExtra(texel, pomShadow, puddle);
    // 水たまりの鏡面を広げる傾きの分散。縁の半分から内側を水面とみなす (solid.fsh の法線の混ぜ方と同じ)
    float puddleWeight = hand ? 0.0 : saturate(puddle * 2.0);
    float puddleVar = puddleSlopeVar() * puddleWeight;
    vec3 specSum = vec3(0.0);

    // 集める項: 太陽 (PCSS・POM・接触影。影マップの外はスカイライトで近似)・手持ち光源・ブロックライトの鏡面・
    //   空 (GI が運ぶ分を引く)・ブロックライト・手持ちの照り返し・GI
    // 省く項: なし (不透明面は全部掛かる)。環境光の鏡面 (反射) は composite2 が足す
    // 項ごとに分けて、太陽 -> 手持ち -> 鏡面 -> 空 -> ブロックライト -> 手持ちの照り返しの順に集める
    // (1 回にまとめると、トレースが太陽の BRDF より前に並んでドライバの出す命令の並びが変わる)
    sp.pomShadow = pomShadow;
#ifdef SSS
    sp.sss = m.sss;
#endif
    // SSS が無ければ透過を足さないので、裏向きの面の厚みの探索と影のにじみも要らない
    SurfaceLights L = gatherSurfaceLights(sp, SL_SUN_SHADOW_MAP_FALLBACK, SL_BLOCK_NONE, SL_SUN_CONTACT | SL_POM);

    // 太陽 / 月
    float moonGain = moonDielectricSpecularGain(m.metalness);
    vec3 color = directLight(m, g.normal, V, L.sun, puddleVar, getCloudSunDiscVisibility(), celestialDiscScale() / moonGain, celestialSpecularStrength() * moonGain, specSum);

#ifdef SSS
    if (m.sss > 0.0) {
        // 厚みに応じた減衰。アルベドの色ほど通りやすい (葉は緑に透ける)
        float thickness = mix(1.0 - L.sunFallback, L.sunShadow.thickness, L.sunShadow.fade);
        vec3 transmit = exp(-thickness * SSS_DENSITY / max(m.sss, 0.05) * (1.15 - m.albedo));
        LightSample through = L.celestial;
        through.irradiance *= transmit * L.cloudShadow * pomShadow;
        color += evalTranslucency(m, g.normal, V, through) * SSS_STRENGTH;
    }
#endif

    // 手持ち光源・ブロックライトの鏡面
    sp.sunFade = L.sunShadow.fade;
    SurfaceLights H = gatherSurfaceLights(sp, SL_SUN_NONE, SL_BLOCK_NONE, SL_HAND);
#ifdef SSS
    color += directLight(m, g.normal, V, H.handMain, puddleVar, 1.0, 1.0, SPECULAR_BLOCK_STRENGTH, specSum) + evalTranslucency(m, g.normal, V, H.handMain) * SSS_STRENGTH;
    color += directLight(m, g.normal, V, H.handOff, puddleVar, 1.0, 1.0, SPECULAR_BLOCK_STRENGTH, specSum) + evalTranslucency(m, g.normal, V, H.handOff) * SSS_STRENGTH;
#else
    color += directLight(m, g.normal, V, H.handMain, puddleVar, 1.0, 1.0, SPECULAR_BLOCK_STRENGTH, specSum);
    color += directLight(m, g.normal, V, H.handOff, puddleVar, 1.0, 1.0, SPECULAR_BLOCK_STRENGTH, specSum);
#endif
    SurfaceLights S = gatherSurfaceLights(sp, SL_SUN_NONE, SL_BLOCK_NONE, SL_BLOCK_SPECULAR);
    for (int j = 0; j < S.blockSpecCount; j++) directSpecular(m, g.normal, V, S.blockSpec[j], puddleVar, SPECULAR_BLOCK_STRENGTH, specSum);

    // 環境光 (空・ブロックライト・GI)
    float ao = g.ao * indirect.a;
    SurfaceLights A = gatherSurfaceLights(sp, SL_SUN_NONE, SL_BLOCK_NONE, SL_SKY | SL_GI);
    vec3 skyAmbient = A.sky * aoMultiBounce(ao, m.albedo + m.f0 * m.metalness);
    vec3 blockLight = gatherSurfaceLights(sp, SL_SUN_NONE, SL_BLOCK_OPAQUE, 0u).block * mix(1.0, ao, AO_BLOCKLIGHT_WEIGHT);
    // 手の見える面は大抵カメラ (= 光源の反対側) を向くので直接光が当たらず真っ黒になる
    // 画面に貼り付いた小物なので、立ち位置のバニラのライトマップ相当を下限にする
    if (hand) blockLight = max(blockLight, blockLightmapFallback(g.lightmap.x));
    else blockLight += gatherSurfaceLights(sp, SL_SUN_NONE, SL_BLOCK_NONE, SL_HAND_FILL).handFill * ao;
    vec3 indirectLight = indirect.rgb * g.ao;
    if (A.giSky > 0.0) {
        // GI は幾何法線で張った半球なので、テクスチャ法線の凹凸は空の SH の向きによる差で戻す
        // (照度として足すのではなく、2 つの法線の SH の比を取るだけなので gatherSurfaceLights を通さない)
        float detail = luminance(getSkyIrradiance(g.normal)) / max(luminance(getSkyIrradiance(g.geoNormal)), 1e-6);
        // ボクセルに入らない小物 (草・柵・エンティティ) の遮蔽は GTAO で足す。ブロックの遮蔽はレイが見ているので半分だけ
        indirectLight *= mix(1.0, clamp(detail, GI_NORMAL_DETAIL_MIN, GI_NORMAL_DETAIL_MAX) * mix(1.0, indirect.a, GI_SKY_GTAO_WEIGHT), A.giSky);
    }
    bool lava = readMaterialId(texel) == MAT_LAVA;
    if (lava) {
        /*
         * 溶岩の面は隣のセルの流体光源 (表面のアンカー) と floodfill に至近距離から照らされ、発光より何倍も明るくなって
         * AgX の肩で彩度が抜け、溶岩の滝が白っぽいサーモン色になった。見た目は発光に任せる
         */
        blockLight *= LAVA_RECEIVED_LIGHT;
        indirectLight *= LAVA_RECEIVED_LIGHT;
    }
    vec3 ambient = skyAmbient + blockLight + indirectLight + minAmbientIrradiance() * ao;
    color += evalDiffuseIrradiance(m, ambient);

    vec3 glow = vec3(0.0);
    if (lava) color += lavaRadiance(g.albedo) * EMISSION_STRENGTH;
    else if (g.emission > 0.0) glow = g.albedo * g.emission * (getVisibleEmissionLuminance() * emissionGain(playerPos, g.geoNormal, g.materialId, hand) * EMISSION_STRENGTH);
    color += glow + specSum;
    float texelPx = SPARKLE_TEXEL_SIZE / max(waterFootprint(length(playerPos), abs(dot(g.geoNormal, V))), 1e-5);
    float texelGate = puddleWeight > 0.0 ? 1.0 : smoothstep(SPARKLE_TEXEL_PX.x, SPARKLE_TEXEL_PX.y, texelPx);
    float sparkle = hand ? 0.0 : luminance(sparkleExcess(specSum, getExposure())) * texelGate;
#ifdef EMISSION_GLARE
    // 発光の白飛び分も鏡面と同じく線形の短い履歴で TAA の外へ渡す。小さな炎は TAA の箱で潰れて滲みに届かない
    if (!hand) sparkle += luminance(sparkleExcess(glow, getExposure()));
#endif
    // 鏡面の白飛び分を a = 1 + 割合で composite2 -> composite19 -> composite20 (TAA の後に足す) へ渡す
    outColor = vec4(color, 1.0 + saturate(sparkle / max(luminance(color), 1e-6)));
}
