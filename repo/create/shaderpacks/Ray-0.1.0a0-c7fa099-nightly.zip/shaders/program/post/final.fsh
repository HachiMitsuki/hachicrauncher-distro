/*
 * final: 歪曲と魚眼の再投影・色収差・シャープ (CAS)・ブルーム合成・球面収差・ベーリンググレア・点像の裾・レンズフレア・口径食・ハレーション・Purkinje・ビネット・露出・
 *        ホワイトバランス・カラーグレーディング・トーンマップ・ルックの LUT・グレイン・ディザ・デバッグ表示
 * 色に掛ける処理は物理的な順 (レンズ -> センサー -> 現像) に並べる
 * post モジュール
 */
//@include "/lib/common/common.glsl"
//@include "/lib/buffers/frame_data.glsl"
//@include "/lib/common/exposure.glsl"
//@include "/lib/common/gbuffer.glsl"
//@include "/lib/post/post_internal.glsl"
//@include "/lib/ids/id_decode.glsl"
//@include "/lib/ids/material_ids.glsl"
//@include "/lib/light/floodfill.glsl"
//@include "/lib/light/voxel.glsl"
//@include "/lib/buffers/formats.glsl"
// BEGIN GENERATED includes (tools/gen_includes.py)
#include "/lib/settings/look.glsl"
#include "/lib/settings/light.glsl"
#include "/lib/settings/surface.glsl"
#include "/lib/settings/sky.glsl"
#include "/lib/settings/post.glsl"
#include "/lib/settings/internal.glsl"
#include "/lib/settings/bool_refs.glsl"
#include "/lib/settings.glsl"
#include "/lib/common/dimension.glsl"
#include "/lib/common/constants.glsl"
#include "/lib/common/uniforms.glsl"
#include "/lib/common/samplers.glsl"
#include "/lib/common/math.glsl"
#include "/lib/common/shading_types.glsl"
#include "/lib/common/common.glsl"
#include "/lib/buffers/frame_data.glsl"
#include "/lib/common/exposure.glsl"
#include "/lib/common/color.glsl"
#include "/lib/common/encoding.glsl"
#include "/lib/common/gbuffer.glsl"
#include "/lib/common/jitter.glsl"
#include "/lib/common/transforms.glsl"
#include "/lib/post/velocity.glsl"
#include "/lib/common/look_presets.glsl"
#include "/lib/post/tonemap.glsl"
#include "/lib/post/post.glsl"
#include "/lib/post/post_constants.glsl"
#include "/lib/post/lens_presets.glsl"
#include "/lib/post/sampling.glsl"
#include "/lib/post/exposure.glsl"
#include "/lib/post/camera.glsl"
#include "/lib/post/grading.glsl"
#include "/lib/post/color_grade.glsl"
#include "/lib/post/bloom.glsl"
#include "/lib/common/noise.glsl"
#include "/lib/post/lens_optics.glsl"
#include "/lib/common/celestial_shape.glsl"
#include "/lib/post/lens_ghosts.glsl"
#include "/lib/post/lens_flare.glsl"
#include "/lib/post/lens.glsl"
#include "/lib/post/post_internal.glsl"
#include "/lib/ids/block_ids.glsl"
#include "/lib/ids/entity_ids.glsl"
#include "/lib/ids/light_ids.glsl"
#include "/lib/ids/material_ids.glsl"
#include "/lib/ids/id_decode.glsl"
#include "/lib/common/voxel_space.glsl"
#include "/lib/buffers/images.glsl"
#include "/lib/buffers/block_data.glsl"
#include "/lib/light/block_data.glsl"
#include "/lib/light/voxel_read.glsl"
#include "/lib/light/voxel.glsl"
#include "/lib/light/floodfill.glsl"
#include "/lib/buffers/formats.glsl"
// END GENERATED includes

#ifdef SPECULAR_SPARKLE
const bool colortex17MipmapEnabled = true;
#endif

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

vec3 debugView(ivec2 texel, vec3 color) {
#if DEBUG_VIEW == 1
    return linearToSrgb(readGBuffer(texel).albedo);
#elif DEBUG_VIEW == 2
    return readGBufferNormal(texel) * 0.5 + 0.5;
#elif DEBUG_VIEW == 3
    return vec3(readGBuffer(texel).lightmap, 0.0);
#elif DEBUG_VIEW == 4
    return linearToSrgb(tonemap(texelFetch(colortex6, texel, 0).rgb));
#elif DEBUG_VIEW == 5
    float depth = texelFetch(depthtex0, texel, 0).r;
    vec3 playerPos = screenToPlayer(vec3(texcoord, depth));
    return linearToSrgb(tonemap(sampleFloodfillVolume(playerPos - normalize(playerPos) * 0.5)));
#elif DEBUG_VIEW == 6
    vec4 gi = texelFetch(colortex8, texel, 0);
    return linearToSrgb(tonemap(gi.rgb)) * gi.a;
#elif DEBUG_VIEW == 7
    // 雲の散乱光に露出を掛けて見る (掛けないと夜や薄明では真っ黒になる)
    return linearToSrgb(tonemap(texelFetch(colortex11, texel, 0).rgb * getExposure()));
#elif DEBUG_VIEW == 8
    return linearToSrgb(tonemap(texelFetch(colortex12, texel, 0).rgb));
#elif DEBUG_VIEW == 9
    return linearToSrgb(tonemap(texture(skyViewSampler, texcoord).rgb));
#elif DEBUG_VIEW == 10
    // 目の高さのボクセル断面 (固体=白, エンティティ=赤, 光源=黄)
    ivec2 xz = ivec2(texcoord * vec2(VOXEL_SIZE.xz));
    ivec3 cell = ivec3(xz.x, VOXEL_HALF.y, xz.y);
    int id = unpackVoxelBlockId(readVoxelBlock(cell));
    bool ent = readVoxelEntity(cell) != 0u;
    return ent ? vec3(1.0, 0.2, 0.2) : (getBlockLightIndex(id) != 0 ? vec3(1.0, 0.9, 0.2) : vec3(id != 0 ? 0.8 : 0.05));
#elif DEBUG_VIEW == 11
    // 最終的に TAA・モーションブラーが使う速度 (ピクセル単位, 1 px で 0.25)。b は colortex15 (エンティティ・手) の有効フラグ
    vec2 vel = (getPreviousUv(texcoord, texelFetch(depthtex0, texel, 0).r) - texcoord) * viewSize();
    return vec3(abs(vel) * 0.25, texelFetch(colortex15, texel, 0).a * 0.5);
#elif DEBUG_VIEW == 12
    return texelFetch(debugSampler, texel, 0).rgb;
#else
    return color;
#endif
}

/*
 * ルックの LUT (表示値 -> 表示値)。トーンマップと sRGB エンコード・表示値のグレードの後、CDL の前に掛ける
 * 表示空間にすると、Resolve・Photoshop の .cube や、恒等の画像に画像編集ソフトで色調補正を掛けたものがそのまま使える。
 * AgX の出力は 0-1 に収まるので定義域の外も出ない。グレインとディザより前なのでノイズを LUT が歪めない
 * 1 = ユーザーの PNG ストリップ (32^3。青を 32 枚横に並べ、各枚は x = 赤、y = 緑で上の行が緑 0)、2 以降 = 同梱の 33^3 の 3D LUT
 * ファイルは tools/gen_look_lut.py で作る
 */
#if LOOK_LUT == 1
uniform sampler2D lookLutStripTex;
const float LOOK_STRIP_SIZE = 32.0;
// 2D のストリップには青の軸の補間が無いので、隣り合う 2 枚を双線形で読んで混ぜる
vec3 applyLookLut(vec3 c) {
    c = saturate(c) * (LOOK_STRIP_SIZE - 1.0);
    float b0 = floor(c.b);
    float b1 = min(b0 + 1.0, LOOK_STRIP_SIZE - 1.0);
    vec2 uv = vec2((c.r + 0.5) / (LOOK_STRIP_SIZE * LOOK_STRIP_SIZE), (c.g + 0.5) / LOOK_STRIP_SIZE);
    vec3 s0 = textureLod(lookLutStripTex, uv + vec2(b0 / LOOK_STRIP_SIZE, 0.0), 0.0).rgb;
    vec3 s1 = textureLod(lookLutStripTex, uv + vec2(b1 / LOOK_STRIP_SIZE, 0.0), 0.0).rgb;
    return mix(s0, s1, c.b - b0);
}
#elif LOOK_LUT >= 2
uniform sampler3D lookLutTex;
const float LOOK_LUT_SIZE = 33.0;
// 格子点の中心に合わせてハードウェアの三重線形で読む (33^3 の誤差は表示値で 1/255 未満)
vec3 applyLookLut(vec3 c) {
    vec3 uvw = saturate(c) * ((LOOK_LUT_SIZE - 1.0) / LOOK_LUT_SIZE) + 0.5 / LOOK_LUT_SIZE;
    return textureLod(lookLutTex, uvw, 0.0).rgb;
}
#endif

vec3 fetchScene(ivec2 p) {
    return sanitizeColor(texelFetch(colortex0, clamp(p, ivec2(0), ivec2(viewSize()) - 1), 0).rgb);
}

// CAS の知覚空間で白 (露出後 1) に当たる値。近傍にこれを超える点があれば暗い側へのはみ出しを止める
const float CAS_HALO_WHITE = 0.5;

// CAS を掛ける知覚空間 (露出込みのチャンネル別 Reinhard, 可逆)
vec3 casEncode(vec3 c, float exposure) { c *= exposure; return c / (1.0 + c); }
vec3 casDecode(vec3 c, float exposure) { c = min(c, 0.999); return c / (1.0 - c) / exposure; }

/*
 * AMD FidelityFX CAS (5 タップ版): 近傍の最小 / 最大から、リンギングが出ない範囲でだけ鋭くする
 * TAA のにじみを戻す最後の一押し。HDR のまま掛けると明るい縁に白フチが出るので知覚空間で掛ける
 * 戻り値はシーン線形での差分 (色収差を掛けた中心にも足せるように)
 */
vec3 casDelta(ivec2 texel, vec3 center, float exposure) {
    // 設定値は小数なのでプリプロセッサでは比べられない (定数畳み込みで分岐は消える)
    if (CAS_STRENGTH <= 0.0) return vec3(0.0);
    vec3 c = casEncode(center, exposure);
    vec3 n = casEncode(fetchScene(texel + ivec2(0, 1)), exposure);
    vec3 s = casEncode(fetchScene(texel + ivec2(0, -1)), exposure);
    vec3 e = casEncode(fetchScene(texel + ivec2(1, 0)), exposure);
    vec3 w = casEncode(fetchScene(texel + ivec2(-1, 0)), exposure);
    vec3 mn = min(c, min(min(n, s), min(e, w)));
    vec3 mx = max(c, max(max(n, s), max(e, w)));
    vec3 amp = sqrt(saturate(min(mn, 1.0 - mx) / max(mx, 1e-4)));
    vec3 wgt = amp * (-1.0 / mix(8.0, 5.0, CAS_STRENGTH));
    vec3 sharp = saturate((c + (n + s + e + w) * wgt) / (1.0 + 4.0 * wgt));
    // 白を超えた点の隣は近傍の最小より暗く沈めない (暗い水の上のきらめきの縁が黒く見えた)。テクスチャの細部は今までどおり鋭くする
    sharp = max(sharp, mn * step(CAS_HALO_WHITE, mx));
    return casDecode(sharp, exposure) - center;
}

#if defined LENS_FLARE && defined HAS_SKY
// フレアの光源 (昼は太陽, 夜は月) の見え具合。composite25 が光源の円盤内を 256 点調べて平滑化した値
float flareVisibility() {
    float v = frameData.postParams[2].x;
    return isnan(v) ? 0.0 : saturate(v);
}
#endif

/*
 * 溶岩の画素の割合 (十字の 5 画素)。溶岩だけ色相を保つトーンマップにする
 * G バッファは TAA のジッター付きで縁の 1 画素が毎フレーム入れ替わるので、近傍で均して切り替えのちらつきを抑える
 */
float lavaToneMask(ivec2 texel) {
    const ivec2 offsets[5] = ivec2[5](ivec2(0), ivec2(1, 0), ivec2(-1, 0), ivec2(0, 1), ivec2(0, -1));
    ivec2 maxTexel = ivec2(viewSize()) - 1;
    float sum = 0.0;
    for (int i = 0; i < 5; i++) {
        if (readMaterialId(clamp(texel + offsets[i], ivec2(0), maxTexel)) == MAT_LAVA) sum += 1.0;
    }
    return sum / 5.0;
}

const float OUTPUT_LEVELS = 255.0;  // 8bit 出力の最大値

void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);
    vec2 uv = texcoord;
    float exposure = getExposure();

    /*
     * レンズ: 歪曲・魚眼の再投影 (以降のシーンの読み出しは全て再投影後の位置 uvL で行う)
     * 直線写像で歪曲の無いプリセットでは定数畳み込みで丸ごと消える
     */
#ifdef LENS_DISTORTION
    const bool distort = LP_K1 != 0.0 || LP_K2 != 0.0 || LP_K3 != 0.0 || LENS_PROJECTION == 1;
#else
    const bool distort = false;
#endif
    // 周辺光量・像面の表を引く正規化半径 (lensProjectUv の説明を参照)
    float rhoLens = sqrt(lensRadius2(uv));
    vec2 uvL = distort ? lensProjectUv(uv, rhoLens) : uv;
    // 描画の範囲の外 (魚眼の「横幅に合わせる」の隅) は黒。縁は出力の 1 画素ぶんで滑らかに落とす
    float inside = 1.0;
#if defined LENS_DISTORTION && LENS_PROJECTION == 1
    #if LENS_FISHEYE_FIT == 1
        vec2 edgePx = min(uvL, 1.0 - uvL) * viewSize();
        vec2 footprint = fwidth(uvL * viewSize());
        inside = saturate(min(edgePx.x, edgePx.y) / max(max(footprint.x, footprint.y), 1e-3) + 0.5);
    #endif
    uvL = clamp(uvL, 0.5 / viewSize(), 1.0 - 0.5 / viewSize());
#endif
    ivec2 texelL = distort ? ivec2(uvL * viewSize()) : texel;
    // 深度と G バッファ (溶岩・フォグ) を読む位置。いつも元画像の座標
    ivec2 texelG = texelL;
    /*
     * 歪曲・魚眼を TAA で組み立てた時 (LENS_WARP_TAA) は、colortex0 とブルームがもう出力の座標なので再投影しない
     * (rhoLens と inside は上で求めたものをそのまま使う)
     */
    if (LENS_WARP_TAA) {
        uvL = uv;
        texelL = texel;
    }
    // 太陽・月のフレアと汚れはレンズ (像面) に固定なので、出力の座標で描く (既存のプリセットは元画像の座標のまま)
#ifdef LENS_FLARE_OUTPUT_SPACE
    const bool flareOutput = true;
#else
    const bool flareOutput = LENS_WARP_TAA;
#endif
    vec2 uvFlare = flareOutput ? uv : uvL;

    vec3 center = distort && !LENS_WARP_TAA ? sanitizeColor(sampleCatmullRom(colortex0, uvL, viewSize())) : fetchScene(texel);
    vec3 hdr = center;

    // レンズ: 倍率色収差 (波長ごとに倍率が違い、画面の隅ほど縁が虹色にずれる)
#ifdef LENS_CHROMATIC
    #if defined LENS_DISTORTION && LENS_PROJECTION == 1
    if (LP_CA != 0.0) hdr = LENS_WARP_TAA ? lensChromaticSample(colortex0, uv, LP_CA) : lensChromaticProjected(colortex0, uv, LP_CA);
    #else
    if (LP_CA != 0.0) hdr = lensChromaticSample(colortex0, uvL, LP_CA);
    #endif
#endif
    hdr = max(hdr + casDelta(texelL, center, exposure), 0.0);

    float lava = lavaToneMask(texelG);
    // 溶岩のブルームの滲みが占める割合。溶岩と同じ色を保つトーンマップに寄せる (AgX では周りの煙・壁の滲みが淡いサーモン色に抜けた)
    float lavaGlowShare = 0.0;
    float depth = texelFetch(depthtex0, texelG, 0).r;

#ifdef SPECULAR_SPARKLE
    /*
     * レンズ: 点像の芯と裾。白を超えた鏡面の点は 1 画素ほどで、実際のカメラでは回折・センサーの芯 (半径 1-2 px) と、収差と
     * 散乱の裾 (r^-2) を引いて丸い光の塊に見える。芯は双線形の 3 x 3 の読みで配る (POINT_CORE_SHARE)
     * 白飛び分 (colortex17) のミップは箱の平均でエネルギーを保つので、4 段を同じエネルギーずつ読んで芯から裾へ配る (総量は変えない)
     * DoF の前の値なので、ボケている点には重ねない (玉ボケに任せる)
     * 球面収差・ブルーム・ヘイズの mix より前に掛ける。後に掛けると、mix で縮んだ hdr から縮む前の白飛び分を引き、点の中心が地まで削られて黒く抜けた
     */
    if (POINT_SPREAD_GAIN > 0.0) {
        float focusFade = POINT_SPREAD_GAIN;
    #ifdef DOF
        float cocDist = depth >= 1.0 ? far * 4.0 : linearizeDepth(fixHandDepth(depth));
        float cocPx = isHandDepth(depth) ? 0.0 : circleOfConfusion(cocDist, max(frameData.focusDistance, 0.1));
        focusFade *= saturate(1.0 - abs(cocPx) / POINT_SPREAD_COC_FADE);
    #endif
        // 配るのは点の光の全部まで。強さで先に裾を増やし、芯は残りの分 (和が 1 を超えると中心の地まで引かれて黒く抜けた)
        float spreadAmount = min((POINT_SPREAD_BASE + POINT_SPREAD_PER_GLARE * LP_VEILING_GLARE) * focusFade, 1.0);
        float coreAmount = min(POINT_CORE_SHARE * focusFade, 1.0 - spreadAmount);
        if (any(greaterThan(textureLod(colortex17, uvL, float(POINT_SPREAD_GATE_LEVEL)).rgb, vec3(0.0)))) {
            vec3 spreadCore = max(textureLod(colortex17, uvL, 0.0).rgb, 0.0);
            vec3 spreadTail = vec3(0.0);
            for (int l = 1; l <= POINT_SPREAD_LEVELS; l++) spreadTail += max(sampleBSplineMip(colortex17, uvL, l), 0.0);
            vec3 coreBlur = vec3(0.0);
            for (int i = 0; i < 25; i++) {
                ivec2 o = ivec2(i % 5, i / 5) - 2;
                ivec2 a = abs(o);
                vec2 offset = vec2(sign(o)) * vec2(POINT_CORE_TAP_X[a.x], POINT_CORE_TAP_X[a.y]);
                coreBlur += max(textureLod(colortex17, uvL + offset * texelSize(), 0.0).rgb, 0.0) * (POINT_CORE_TAP_W[a.x] * POINT_CORE_TAP_W[a.y]);
            }
            /*
             * 芯と裾へ配る分は中心から引く。colortex17 は DoF・モーションブラー・色収差の前の値なので、ボケた点や色ごとにずれた点では
             * hdr の中心に同じだけの白飛び分が残っていない。引くのは、TAA の出した白飛び分の外の色 (colortex13) を超えて残っている分まで
             * (ピントの前後で中心だけ地まで引かれ、周りが光って中心が黒・緑・紫の 1 画素に抜けた)
             */
            vec3 given = (spreadAmount + coreAmount) * spreadCore;
            vec3 remain = max(hdr - textureLod(colortex13, uvL, 0.0).rgb, 0.0);
            hdr += spreadAmount * spreadTail / float(POINT_SPREAD_LEVELS) + coreAmount * coreBlur - min(given, remain);
        }
    }
#endif

    // レンズ: ブルーム (PSF の畳み込みとして mix。総エネルギーは変えない)
#ifdef BLOOM
    BloomBands bands;
    vec3 bloom = sampleBloom(uvL, bands);
    #ifdef LENS_SOFT_FOCUS
        // 球面収差: ピントが合っていても低い周波数の滲みが乗る (開放ほど強い)
        hdr = mix(hdr, bands.narrow, saturate(LP_SOFT_FOCUS * LENS_SOFT_FOCUS_AMOUNT * lensApertureFactor() * GLOW_GAIN));
        #ifdef LENS_SOFT_HALO_TABLE
            // 処方の球面収差のハロー (FA 28 Soft など)。半径と割合は F 値で変わり、絞ると消える
            vec4 softHalo = lensSoftHalo(uvL);
            hdr = mix(hdr, softHalo.rgb, saturate(softHalo.a * LENS_SOFT_HALO_GAIN * GLOW_GAIN));
        #endif
    #endif
    /*
     * 溶岩の上は自分のブルーム (LAVA_BLOOM_GAIN 倍) が一様に乗って暗い殻が持ち上がり、模様が平らになる
     * 溶岩の画素だけ混合率を下げ、滲みは周りに出す
     */
    float bloomBase = LOOK_BLOOM_STRENGTH * BLOOM_AMOUNT * GLOW_GAIN;
    float bloomMixRaw = bloomBase;
    #ifdef HAS_SKYLIGHT
    float night = 1.0 - smoothstep(NIGHT_BLOOM_SUN_Y.x, NIGHT_BLOOM_SUN_Y.y, getSunDir().y);
    bloomMixRaw = min(bloomBase * (1.0 + (NIGHT_BLOOM_GAIN - 1.0) * night * eyeOutdoor()), max(bloomBase, NIGHT_BLOOM_MIX_MAX));
    #endif
    float bloomMix = saturate(bloomMixRaw) * (1.0 - LAVA_SELF_BLOOM_CUT * lava);
    hdr = mix(hdr, bloom, bloomMix);
    lavaGlowShare = saturate(bloomMix * bands.lava / max(luminance(hdr), 1e-6));

    // ブルーミーフォグ: 遠くと雨・水中ほど広いブルームで霞ませる (全面の滲みは弱く)
    float dist = depth >= 1.0 ? far : linearizeDepth(fixHandDepth(depth));
    float fogFactor = (1.0 - exp(-dist / BLOOM_FOG_DISTANCE)) * mix(LK_BLOOM_FOG_CLEAR, 1.0, rainStrength);
    float water = isEyeInWater == 1 ? 1.0 : 0.0;
    float wideAmount = LOOK_BLOOM_FOG * mix(fogFactor, 1.0, water)
                     + LOOK_BLOOM_STRENGTH * BLOOM_AMOUNT * (rainStrength * BLOOM_RAIN_BOOST + water * BLOOM_WATER_BOOST);
    hdr = mix(hdr, bands.wide, saturate(wideAmount * GLOW_GAIN));

    #ifdef LENS_VEILING_GLARE
        // ベーリンググレア: レンズ面と鏡筒の散乱で画面全体に薄いヘイズが乗り、暗部が持ち上がる
        hdr = mix(hdr, bands.widest, saturate(LP_VEILING_GLARE * LENS_VEIL_HAZE * GLOW_GAIN));
    #endif
    #ifdef LENS_DIRT
        // 汚れは近くの明るい光を散乱して光る (明るい物の周りだけ模様が浮かぶ)
        if (LP_DIRT > 0.0) {
            vec3 lit = max(bands.wide - LENS_SCREEN_THRESHOLD * 0.3 / exposure, 0.0);
            hdr += lit * (lensDirt(uvFlare) * LP_DIRT * LENS_DIRT_BLOOM_GAIN * FLARE_GAIN);
        }
    #endif
    #if defined LENS_SCREEN_FLARE && defined LENS_FLARE
        // 明るい画素のゴーストと横ストリーク (composite24)
        hdr += sampleFlareTile(uvL);
    #endif
#endif

    // レンズ: 太陽・月のフレア (ゴースト・スターバースト・ハロー・グレア・汚れ・ストリーク)
#if defined LENS_FLARE && defined HAS_SKY
    if (shadowLightPosition.z < 0.0) {
        float vis = flareVisibility();
        if (vis > 0.0) {
            vec2 lightUv = viewToScreen(shadowLightPosition).xy;
            if (distort && flareOutput) lightUv = lensForwardUv(lightUv);
            vec3 lightColor = sanitizeColor(frameData.shadowLightIrradiance.rgb);
            vec3 lightTint = lightColor / max(luminance(lightColor), 1e-6);
            // 太陽が沈むと光源は月に切り替わる (薄明は照度が小さいので境目は目立たない)
            float day = smoothstep(-0.1, 0.1, getSunDir().y);
            float gain = mix(LENS_MOON_FLARE, 1.0, day);
            float starGain = mix(LENS_MOON_STARBURST, 1.0, day);
            hdr += lensFlare(uvFlare, lightUv, lightTint, starGain) * lightColor * (vis * gain * FLARE_GAIN);
        }
    }
#endif

    // レンズ: トリウムガラスの黄変 (青を吸う。明るさは変えない)
    if (LP_YELLOWING > 0.0) {
        vec3 tint = mix(vec3(1.0), LENS_YELLOWING_TINT, LP_YELLOWING);
        hdr *= tint / luminance(tint);
    }

    // レンズ: 周辺減光 (演出のビネット + 口径食。処方のあるレンズは自然減光込みの周辺光量の表)
    hdr *= vignette(uv);
#ifdef LENS_OPTICAL_VIGNETTING
    #ifdef LENS_RI_TABLE
    hdr *= lensRelativeIllumination(rhoLens);
    #else
    if (LP_CATS_EYE > 0.0) hdr *= lensOpticalVignette(uv);
    #endif
#endif

    // フィルム: ハレーション (フィルムベースで反射した光が赤い層だけを感光させる。レンズの後段)
#if defined BLOOM && defined LENS_HALATION
    if (LP_HALATION > 0.0) {
        float halation = max(luminance(bands.mid) * exposure - LENS_HALATION_THRESHOLD, 0.0) / exposure;
        hdr += LENS_HALATION_TINT / luminance(LENS_HALATION_TINT) * (halation * LP_HALATION * LENS_HALATION_GAIN * GLOW_GAIN);
    }
#endif

    hdr *= inside;

    // 目 / センサー: Purkinje 効果 -> 露出
    hdr = applyPurkinje(hdr, frameData.averageLuminance, exposure);
    vec3 color = hdr * exposure;

    /*
     * ---- 現像: ホワイトバランス -> ティント・オフセット -> コントラスト -> 明部の伸び -> ゾーン・圧縮・持ち上げ -> 彩度 ->
     *      バイブランス・色相ごと -> トーンマップ (グレーディングの順番は lib/post/color_grade.glsl) ----
     */
#if WHITE_BALANCE != 6500
    color = applyWhiteBalance(color, float(WHITE_BALANCE));
#endif
#ifdef GRADING
    color = gradeBalance(color);
    color = applyContrast(color, LOOK_CONTRAST, G_PIVOT_LEVEL);
#else
    color = applyContrast(color, LOOK_CONTRAST, EXPOSURE_KEY);
#endif
    if (LK_HIGHLIGHT != 1.0) color = applyHighlightRange(color, LK_HIGHLIGHT);
#ifdef GRADING
    color = gradeZones(color);
#endif
    color = applySaturation(color, LOOK_SATURATION);
#ifdef GRADING
    color = gradeChroma(color);
#endif
    /*
     * 溶岩の見た目の明るさ。表示の段でだけ上げ、露出の測光・ブルーム・反射・周りへの光は変えない
     * 赤はほぼ上限なので、明るさは tonemapEmissive で緑 (と少し青) が持ち上がる形で出る (暗い殻 -> 橙 -> 黄の割れ目)
     */
    color *= 1.0 + LAVA_BRIGHTNESS * lava;
    lava = max(lava, lavaGlowShare);
    color = lava > 0.0 ? mix(tonemap(color), tonemapEmissive(color), lava) : tonemap(color);
    color = linearToSrgb(color);
    // 表示値のグレード (リフト・ガンマ・ゲイン -> カーブ -> スプリットトーン) は、フィルムの LUT の下 (前) に置く
#ifdef GRADING
    color = gradeDisplay(color);
#endif
#if LOOK_LUT > 0
    color = mix(color, applyLookLut(color), LOOK_LUT_STRENGTH);
#endif
    // CDL はグレーディング用の表示値 (sRGB エンコード後) に掛ける。ASC の想定する扱いに近く、効き方が直感的
    // 既定値では恒等変換 (プリプロセッサで浮動小数の比較ができないので常に掛ける)
    color = saturate(applyCdl(color, vec3(CDL_SLOPE), vec3(CDL_OFFSET), vec3(CDL_POWER), CDL_SATURATION));
    color = applyGrain(color, gl_FragCoord.xy);

    color = debugView(texel, color);
    // 8bit 出力のバンディング対策
    color += (interleavedGradientNoise(gl_FragCoord.xy, frameCounter) - 0.5) / OUTPUT_LEVELS;
    outColor = vec4(color, 1.0);
}
