#version 460 compatibility
#define WORLD_OVERWORLD
#include "/program/surface/lightning.fsh"
