#version 460
#define WORLD_OVERWORLD
#include "/program/light/frame_begin.csh"
