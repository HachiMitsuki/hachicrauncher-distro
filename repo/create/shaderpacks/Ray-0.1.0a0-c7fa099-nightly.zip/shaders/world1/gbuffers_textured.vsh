#version 460 compatibility
#define WORLD_END
#define GBUF_TEXTURED
#include "/program/surface/gbuffers_solid.vsh"
