/*
 * 実行時のブロックデータ参照 (SSBO blockData は setup.csh が lib/light/light_table.glsl から構築)
 */
#ifndef LIGHT_BLOCK_DATA_GLSL
#define LIGHT_BLOCK_DATA_GLSL

//@include "/lib/settings.glsl"
//@include "/lib/common/color.glsl"
//@include "/lib/common/constants.glsl"
//@include "/lib/common/math.glsl"
//@include "/lib/common/noise.glsl"
//@include "/lib/common/uniforms.glsl"
//@include "/lib/buffers/block_data.glsl"

LightDef getLightDef(int index) { return blockData.lightDefs[clamp(index, 0, LIGHT_TABLE_SIZE - 1)]; }
vec4 getTint(int index) { return blockData.tints[clamp(index, 0, TINT_TABLE_SIZE - 1)]; }
uvec4 getShape(int index) { return blockData.shapes[clamp(index, 0, SHAPE_TABLE_SIZE - 1)]; }
// ボクセル ID の平均の色 (線形アルベド)。floodfill の照り返しとボクセル RT の画面外の当たりに使う
vec3 getBlockAlbedo(int voxelId) {
    return srgbToLinear(unpackUnorm4x8(blockData.albedo[voxelId & (ALBEDO_TABLE_SIZE - 1)]).rgb);
}
// 面の向きが分かる時 (レイの当たり)。上向きの面は上面の色 (草ブロックは全体の平均だと側面の土で茶色になる)
vec3 getBlockAlbedo(int voxelId, vec3 faceNormal) {
    int i = voxelId & (ALBEDO_TABLE_SIZE - 1);
    return srgbToLinear(unpackUnorm4x8(faceNormal.y > 0.5 ? blockData.albedoUp[i] : blockData.albedo[i]).rgb);
}

// 光源の実効レベル。at_midBlock.w (Iris 1.7+) が 0 ならテーブルの既定値を使う
float resolveLightLevel(LightDef d, float attributeLevel) {
    return attributeLevel > 0.5 ? attributeLevel : d.params.z;
}

// 光源 1 つの放射の強さ (LightInstance.colorSize.rgb に入れる値)
vec3 lightEmission(LightDef d, float level) {
    return d.color.rgb * d.color.a * (level / LIGHT_LEVEL_MAX) * BLOCKLIGHT_ILLUMINANCE * BLOCKLIGHT_BRIGHTNESS;
}

// 到達半径 (ブロック)。レベルに比例
float lightRange(LightDef d, float level) { return d.params.x * level / LIGHT_LEVEL_MAX; }

/*
 * 距離減衰の 1 次・2 次の係数 (1 / (1 + a d + b d^2))
 * 純粋な逆二乗 (a = 0, b = 1) は 1 ブロックに対して 4 ブロックで 1/8、7 ブロックで 1/25 になり、
 * バニラの光レベル (1 ブロックごとに 1 段: 4 ブロックで約 1/2、7 ブロックで約 1/4) よりずっと狭い光だまりになった
 * 実際の部屋では壁・床の多重反射が遠くを持ち上げるので、それを 1 次の項で近似し、バニラの到達距離感に寄せる
 */
const float LIGHT_FALLOFF_LINEAR = 0.3;
const float LIGHT_FALLOFF_QUADRATIC = 0.035;
// 1 ブロックの距離で素の逆二乗 (0.5) と同じ照度になるように掛ける正規化 (1 + a + b) / 2
const float LIGHT_FALLOFF_NORM = (1.0 + LIGHT_FALLOFF_LINEAR + LIGHT_FALLOFF_QUADRATIC) * 0.5;

/*
 * 距離減衰。1 次 + 2 次の減衰に、到達半径で滑らかに 0 へ落とす窓関数を掛ける
 * (Karis 2013 の窓。半径外の光源を打ち切ってもポップしない)
 */
float lightFalloff(float dist, float range) {
    float x = saturate(1.0 - pow4(dist / max(range, EPS)));
    return x * x * LIGHT_FALLOFF_NORM / (1.0 + dist * (LIGHT_FALLOFF_LINEAR + LIGHT_FALLOFF_QUADRATIC * dist));
}

/*
 * 光源の面からの近距離の放射 (lightFalloff に足す係数)
 * lightFalloff は遠くを持ち上げた分だけ光源のすぐそばで逆二乗より緩く、光源を付けた壁や発光ブロックの足元が
 * 周りとあまり変わらない明るさになる。光源を見かけの半径 x LIGHT_NEAR_RADIUS_SCALE の発光面とみなし、
 * 球の面光源の形態係数 r^2 / (d^2 + r^2) で光源の周りだけを明るくする
 */
const float LIGHT_NEAR_CONTACT = 6.0;       // 光源に接した面の係数 (1 ブロック先の lightFalloff は 0.5)
const float LIGHT_NEAR_RADIUS_SCALE = 2.5;  // 発光面の半径 / 光源の見かけの半径 (炎や発光の照り返しで光る範囲は光源より広い)
const float LIGHT_NEAR_REACH = 6.0;         // この距離で 0 へ落とす (ブロック)

float lightNearField(float dist, float radius) {
    float r2 = radius * radius * (LIGHT_NEAR_RADIUS_SCALE * LIGHT_NEAR_RADIUS_SCALE);
    float w = saturate(1.0 - dist / LIGHT_NEAR_REACH);
    return LIGHT_NEAR_CONTACT * r2 / (dist * dist + r2) * (w * w);
}

/*
 * 球光源の NdotL。光源の見かけの半径ぶん地平線の下まで回り込ませる (wrap 近似)
 * 点光源の NdotL のままだと大きな光源 (グロウストーン等) の横の面が不自然に真っ暗になる
 */
float sphereLightNdotL(vec3 n, vec3 dir, float dist, float radius) {
    float sinA = saturate(radius / max(dist, EPS));
    return saturate((dot(n, dir) + sinA) / (1.0 + sinA));
}

// フリッカーの速さ (1 秒あたりの揺らぎ数) と最大の暗くなり幅
const float FLICKER_SPEED = 6.0;
const float FLICKER_DEPTH = 0.3;
// 光源ごとの位相のずらし幅、2 オクターブ目の周波数倍率と重み
const float FLICKER_SEED_PHASE = 0.37;
const float FLICKER_OCTAVE_FREQ = 2.3;
const float FLICKER_WEIGHT_0 = 0.65;
const float FLICKER_WEIGHT_1 = 0.35;

/*
 * 炎系光源の明るさの揺らぎ倍率 (1 以下)。seed は光源ごとに固定の値 (ワールドのセル座標等)
 * 光源ごとに位相をずらした 2 オクターブの 1 次元値ノイズ。全光源が同期して揺れると不自然なため
 */
float lightFlicker(float amount, uvec3 seed) {
#ifdef LIGHT_FLICKER
    if (amount <= 0.0) return 1.0;
    uint h = pcg3d(seed).x;
    float t = frameTimeCounter * FLICKER_SPEED + float(h & 1023u) * FLICKER_SEED_PHASE;
    float n = 0.0;
    for (int o = 0; o < 2; o++) {
        float i = floor(t);
        float f = fract(t);
        f = f * f * (3.0 - 2.0 * f);
        uint base = h + uint(o) * 7919u;
        float a = hash1(base + uint(int(i) & 0xFFFF));
        float b = hash1(base + uint((int(i) + 1) & 0xFFFF));
        n += mix(a, b, f) * (o == 0 ? FLICKER_WEIGHT_0 : FLICKER_WEIGHT_1);
        t *= FLICKER_OCTAVE_FREQ;
    }
    return 1.0 - amount * FLICKER_DEPTH * n;
#else
    return 1.0;
#endif
}

#endif
