/*
 * エンティティの三角形による光源シャドウ (light モジュール)
 * 占有ボクセル (0.5 ブロックのサブセル) では影が箱型になり、プレイヤーの影が「体の形」ではなく
 * 「1 ブロック分が欠けた」ように見えた。shadow_entities.gsh が三角形そのものを SSBO 4 に書き、
 * 光源シャドウのレイは 2 段の AABB (グループ -> クラスタ) で絞ってから Möller-Trumbore で判定する
 *
 * 容量の配分: [プレイヤー | カメラ近傍 | 遠方 (floodfill で照らされている所)] を別々のカウンタで確保する
 *   GS の実行順は決まらないので、優先度は領域ごとの容量で付ける。プレイヤーは専用領域なので必ず入る
 *   近傍で溢れた三角形は遠方の領域へ回し、それでも溢れたら占有ボクセルへ書く (形は箱になるが影は消えない)
 * クラスタ (8 スロット) とグループ (128 スロット) の AABB は GS が atomicMin/Max で直接広げる
 *   同じ描画呼び出しの連続した三角形はほぼ連続したスロットに入るので、クラスタは部位の面程度の小さい箱になる
 *   (順序が崩れても箱が大きくなるだけで、判定結果は変わらない)
 *   大きさは計測で決めた (32/256 よりモブ 8 体の場面で約 2 倍速い)
 * 透明部分: 三角形の重心座標を 8x8 に区切った各セルのアルファを GS で読み、64bit のマスクにする
 *   (スケルトンの肋骨・スキンの外側レイヤー等。全部透明な三角形は保持しない)
 */
#ifndef LIGHT_ENTITY_TRI_GLSL
#define LIGHT_ENTITY_TRI_GLSL

//@include "/lib/settings.glsl"
//@include "/lib/common/color.glsl"
//@include "/lib/common/math.glsl"
//@include "/lib/common/samplers.glsl"
//@include "/lib/common/voxel_space.glsl"
//@include "/lib/buffers/entity_tris.glsl"
//@include "/lib/light/floodfill.glsl"

const uint ENTITY_TRI_CAPACITY = uint(min(LIGHT_ENTITY_TRIANGLES, ENTITY_TRI_MAX));
// プレイヤー 1 人分 (外側レイヤー・防具・手持ち・エリトラ込み) に足りる量。ENTITY_TRI_GROUP の倍数
const uint ENTITY_TRI_PLAYER_CAP = 1024u;
// 近傍と遠方で残りを半分ずつ (容量の候補はどれも ENTITY_TRI_GROUP の倍数に割り切れる)
const uint ENTITY_TRI_OTHER_CAP = (ENTITY_TRI_CAPACITY - ENTITY_TRI_PLAYER_CAP) / 2u;
// 近傍: 手持ち光源の到達範囲を含む距離。遠方: これより先は占有ボクセルに任せる (player 空間の距離)
const float ENTITY_TRI_NEAR_DIST = 16.0;
const float ENTITY_TRI_FAR_DIST = 48.0;
// 遠方の三角形は floodfill の照度がこれ以上の所だけ保持する (光の届かない所の影は見えない)
const float ENTITY_TRI_FAR_MIN_FLOOD = 0.01;
// アルファの閾値 (shadow_entities.fsh の discard と同じ)
const float ENTITY_TRI_ALPHA_CUTOFF = 0.1;
// 着色点側で無視する距離。法線方向の押し出し (TRACE_NORMAL_OFFSET) と合わせて自分の面での即ヒットを防ぐ
const float ENTITY_TRI_T_MIN = 0.01;
// AABB の判定を少し太らせる (頂点の丸め誤差で縁の三角形を取りこぼさないため)
const float ENTITY_TRI_AABB_PAD = 1e-3;

uint entityTriRegionStart(int region) {
    return region == 0 ? 0u : (region == 1 ? ENTITY_TRI_PLAYER_CAP : ENTITY_TRI_PLAYER_CAP + ENTITY_TRI_OTHER_CAP);
}
uint entityTriRegionCap(int region) { return region == 0 ? ENTITY_TRI_PLAYER_CAP : ENTITY_TRI_OTHER_CAP; }

// float の大小と uint の大小が一致する符号化 (atomicMin/Max で AABB を広げるため)
uint entityTriOrderedFromFloat(float f) {
    uint u = floatBitsToUint(f);
    return (u & 0x80000000u) != 0u ? ~u : (u | 0x80000000u);
}
float entityTriFloatFromOrdered(uint u) {
    return uintBitsToFloat((u & 0x80000000u) != 0u ? (u & 0x7FFFFFFFu) : ~u);
}

/*
 * 三角形の透明部分のマスク。重心座標 (a, b) (a = e1 方向, b = e2 方向) を 8x8 に区切り、
 * 三角形に入る 36 セルの中心でテクスチャのアルファを読む
 * color: 不透明なセルのテクスチャの色の平均 (sRGB)。同じ読みで集める
 */
uvec2 entityTriAlphaMask(vec2 uv0, vec2 uv1, vec2 uv2, float vertexAlpha, out vec3 color) {
    uvec2 mask = uvec2(0u);
    vec3 sum = vec3(0.0);
    float n = 0.0;
    for (int j = 0; j < 8; j++) {
        for (int i = 0; i < 8 - j; i++) {
            vec2 b = (vec2(i, j) + 0.5) / 8.0;
            vec2 uv = uv0 + (uv1 - uv0) * b.x + (uv2 - uv0) * b.y;
            vec4 t = textureLod(gtexture, uv, 0.0);
            if (t.a * vertexAlpha < ENTITY_TRI_ALPHA_CUTOFF) continue;
            sum += t.rgb;
            n += 1.0;
            int bit = i + j * 8;
            if (bit < 32) mask.x |= 1u << uint(bit);
            else mask.y |= 1u << uint(bit - 32);
        }
    }
    color = sum / max(n, 1.0);
    return mask;
}

// 三角形の平均の色 (線形のアルベド)
vec3 entityTriAlbedo(uint index) { return srgbToLinear(unpackUnorm4x8(entityTris.tris[index].color).rgb); }

// 三角形の面の向き (向きの裏表は決めない)
vec3 entityTriNormal(uint index) { return normalize(cross(entityTris.tris[index].e1, entityTris.tris[index].e2)); }

// 書く関数は書くプログラム (shadow_entities・shadow_block・begin) だけが持つ (ほかでは entityTris が readonly)
#ifdef SSBO_ENTITY_TRIS_WRITE
void entityTriGrowBounds(bool group, uint index, vec3 lo, vec3 hi) {
    uint base = index * 6u;
    for (int k = 0; k < 3; k++) {
        uint mn = entityTriOrderedFromFloat(lo[k]);
        uint mx = entityTriOrderedFromFloat(hi[k]);
        if (group) {
            atomicMin(entityTris.groupBounds[base + uint(k)], mn);
            atomicMax(entityTris.groupBounds[base + 3u + uint(k)], mx);
        } else {
            atomicMin(entityTris.clusterBounds[base + uint(k)], mn);
            atomicMax(entityTris.clusterBounds[base + 3u + uint(k)], mx);
        }
    }
}

/*
 * shadow_entities.gsh から三角形 1 つを書く。p* は player 空間, uv* はテクスチャ座標, vertexColor は 3 頂点の色の平均
 * 戻り値 false = 保持しなかった (遠すぎる・容量超過)。呼び出し側は占有ボクセルへ退避する
 * 透明・縮退・体積外の三角形は遮蔽物にならないので true (何もしない) を返す
 */
bool storeEntityTriangle(vec3 p0, vec3 p1, vec3 p2, vec2 uv0, vec2 uv1, vec2 uv2, vec4 vertexColor, bool isPlayer) {
    vec3 v0 = playerToVoxel(p0);
    vec3 v1 = playerToVoxel(p1);
    vec3 v2 = playerToVoxel(p2);
    vec3 lo = min(v0, min(v1, v2));
    vec3 hi = max(v0, max(v1, v2));
    if (any(greaterThanEqual(lo, vec3(VOXEL_SIZE))) || any(lessThan(hi, vec3(0.0)))) return true;
    vec3 e1 = v1 - v0;
    vec3 e2 = v2 - v0;
    if (lengthSqr(cross(e1, e2)) < 1e-12) return true;

    int region = 0;
    if (!isPlayer) {
        vec3 c = (p0 + p1 + p2) / 3.0;
        float d = length(c);
        if (d < ENTITY_TRI_NEAR_DIST) {
            region = 1;
        } else if (d < ENTITY_TRI_FAR_DIST) {
            region = 2;
#ifdef FLOODFILL
            ivec3 cell = ivec3(floor(playerToVoxel(c)));
            if (!isInVoxelVolume(cell) || maxOf(fetchFlood(cell)) < ENTITY_TRI_FAR_MIN_FLOOD) return false;
#endif
        } else {
            return false;
        }
    }

    vec3 texColor;
    uvec2 mask = entityTriAlphaMask(uv0, uv1, uv2, vertexColor.a, texColor);
    if (mask.x == 0u && mask.y == 0u) return true;

    uint slot = atomicAdd(entityTris.counts[region], 1u);
    if (region == 1 && slot >= entityTriRegionCap(1)) {
        /*
         * 近傍が溢れたら遠方の領域を使う (近傍を優先する。遠方が空いている場面が多い)
         * GS の実行順は決まらないので、溢れると近いモブが箱の影に戻っていた
         */
        region = 2;
        slot = atomicAdd(entityTris.counts[2], 1u);
    }
    if (slot >= entityTriRegionCap(region)) {
        atomicAdd(entityTris.counts[3], 1u);
        return false;
    }
    uint index = entityTriRegionStart(region) + slot;
    entityTris.tris[index] = EntityTriangle(v0, mask.x, e1, mask.y, e2, packUnorm4x8(vec4(saturate(texColor * vertexColor.rgb), 1.0)));
    entityTriGrowBounds(false, index / uint(ENTITY_TRI_CLUSTER), lo, hi);
    entityTriGrowBounds(true, index / uint(ENTITY_TRI_GROUP), lo, hi);
    return true;
}

// begin.csh: 今フレームの三角形を空にする (1 スレッド = 1 クラスタ / グループの AABB)
void clearEntityTriangles(uint i) {
    if (i < uint(ENTITY_TRI_MAX_CLUSTERS * 6)) entityTris.clusterBounds[i] = (i % 6u) < 3u ? 0xFFFFFFFFu : 0u;
    if (i < uint(ENTITY_TRI_MAX_GROUPS * 6)) entityTris.groupBounds[i] = (i % 6u) < 3u ? 0xFFFFFFFFu : 0u;
    if (i < 4u) entityTris.counts[i] = 0u;
}
#endif

// 区間 [t0, t1] のレイが AABB (bounds の base から 6 uint) に入るか
bool entityTriRayBox(bool group, uint index, vec3 ro, vec3 rdInv, float t0, float t1) {
    uint base = index * 6u;
    vec3 lo, hi;
    if (group) {
        lo = vec3(entityTriFloatFromOrdered(entityTris.groupBounds[base]), entityTriFloatFromOrdered(entityTris.groupBounds[base + 1u]),
                  entityTriFloatFromOrdered(entityTris.groupBounds[base + 2u]));
        hi = vec3(entityTriFloatFromOrdered(entityTris.groupBounds[base + 3u]), entityTriFloatFromOrdered(entityTris.groupBounds[base + 4u]),
                  entityTriFloatFromOrdered(entityTris.groupBounds[base + 5u]));
    } else {
        lo = vec3(entityTriFloatFromOrdered(entityTris.clusterBounds[base]), entityTriFloatFromOrdered(entityTris.clusterBounds[base + 1u]),
                  entityTriFloatFromOrdered(entityTris.clusterBounds[base + 2u]));
        hi = vec3(entityTriFloatFromOrdered(entityTris.clusterBounds[base + 3u]), entityTriFloatFromOrdered(entityTris.clusterBounds[base + 4u]),
                  entityTriFloatFromOrdered(entityTris.clusterBounds[base + 5u]));
    }
    vec3 a = (lo - ENTITY_TRI_AABB_PAD - ro) * rdInv;
    vec3 b = (hi + ENTITY_TRI_AABB_PAD - ro) * rdInv;
    float tn = max(maxOf(min(a, b)), t0);
    float tf = min(minOf(max(a, b)), t1);
    return tn <= tf;
}

// Möller-Trumbore (両面)。透明なセルに当たった場合は外れ。戻り値は当たった距離 (外れは負)
float entityTriHitT(uint index, vec3 ro, vec3 dir, float t0, float t1) {
    EntityTriangle tri = entityTris.tris[index];
    vec3 p = cross(dir, tri.e2);
    float det = dot(tri.e1, p);
    if (abs(det) < 1e-12) return -1.0;
    float inv = 1.0 / det;
    vec3 s = ro - tri.v0;
    float a = dot(s, p) * inv;
    if (a < 0.0 || a > 1.0) return -1.0;
    vec3 q = cross(s, tri.e1);
    float b = dot(dir, q) * inv;
    if (b < 0.0 || a + b > 1.0) return -1.0;
    float t = dot(tri.e2, q) * inv;
    if (t < t0 || t > t1) return -1.0;
    ivec2 c = min(ivec2(vec2(a, b) * 8.0), ivec2(7));
    if (c.x + c.y > 7) c.y = 7 - c.x;
    int bit = c.x + c.y * 8;
    uint word = bit < 32 ? tri.maskLo : tri.maskHi;
    return (word & (1u << uint(bit & 31))) != 0u ? t : -1.0;
}

bool entityTriHit(uint index, vec3 ro, vec3 dir, float t0, float t1) { return entityTriHitT(index, ro, dir, t0, t1) >= 0.0; }

/*
 * ボクセル空間のレイ ro + dir * t (dir は単位ベクトル) が区間 [t0, t1] でエンティティの三角形に当たるか
 * player: 自分 (current_player) の三角形, others: それ以外のエンティティの三角形
 */
bool traceEntityTriangles(vec3 ro, vec3 dir, float t0, float t1, bool player, bool others) {
    if (t1 <= t0) return false;
    vec3 rdInv = sign(dir + 1e-20) / max(abs(dir), vec3(1e-7));
    for (int region = 0; region < 3; region++) {
        if (region == 0 ? !player : !others) continue;
        uint n = min(entityTris.counts[region], entityTriRegionCap(region));
        if (n == 0u) continue;
        uint start = entityTriRegionStart(region);
        uint end = start + n;
        for (uint g = start / uint(ENTITY_TRI_GROUP); g * uint(ENTITY_TRI_GROUP) < end; g++) {
            if (!entityTriRayBox(true, g, ro, rdInv, t0, t1)) continue;
            uint gEnd = min(end, (g + 1u) * uint(ENTITY_TRI_GROUP));
            for (uint c = g * uint(ENTITY_TRI_GROUP / ENTITY_TRI_CLUSTER); c * uint(ENTITY_TRI_CLUSTER) < gEnd; c++) {
                if (!entityTriRayBox(false, c, ro, rdInv, t0, t1)) continue;
                uint cEnd = min(gEnd, (c + 1u) * uint(ENTITY_TRI_CLUSTER));
                for (uint i = c * uint(ENTITY_TRI_CLUSTER); i < cEnd; i++) {
                    if (entityTriHit(i, ro, dir, t0, t1)) return true;
                }
            }
        }
    }
    return false;
}

/*
 * 領域 region (0 = 自分) の三角形のうち、ボクセル空間のレイ ro + dir * t が区間 [t0, t1] で一番近くで当たるもの
 * 戻り値は三角形の番号 (外れは ENTITY_TRI_NONE)、tHit に距離。箱の判定は今の一番近い距離までで打ち切る
 */
const uint ENTITY_TRI_NONE = 0xFFFFFFFFu;

uint traceEntityTrianglesClosest(vec3 ro, vec3 dir, float t0, float t1, int region, out float tHit) {
    tHit = t1;
    uint best = ENTITY_TRI_NONE;
    if (t1 <= t0) return best;
    uint n = min(entityTris.counts[region], entityTriRegionCap(region));
    if (n == 0u) return best;
    vec3 rdInv = sign(dir + 1e-20) / max(abs(dir), vec3(1e-7));
    uint start = entityTriRegionStart(region);
    uint end = start + n;
    for (uint g = start / uint(ENTITY_TRI_GROUP); g * uint(ENTITY_TRI_GROUP) < end; g++) {
        if (!entityTriRayBox(true, g, ro, rdInv, t0, tHit)) continue;
        uint gEnd = min(end, (g + 1u) * uint(ENTITY_TRI_GROUP));
        for (uint c = g * uint(ENTITY_TRI_GROUP / ENTITY_TRI_CLUSTER); c * uint(ENTITY_TRI_CLUSTER) < gEnd; c++) {
            if (!entityTriRayBox(false, c, ro, rdInv, t0, tHit)) continue;
            uint cEnd = min(gEnd, (c + 1u) * uint(ENTITY_TRI_CLUSTER));
            for (uint i = c * uint(ENTITY_TRI_CLUSTER); i < cEnd; i++) {
                float t = entityTriHitT(i, ro, dir, t0, tHit);
                if (t >= 0.0) {
                    tHit = t;
                    best = i;
                }
            }
        }
    }
    return best;
}

#endif
