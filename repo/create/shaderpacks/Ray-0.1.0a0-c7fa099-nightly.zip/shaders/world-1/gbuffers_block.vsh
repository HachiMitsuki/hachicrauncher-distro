#version 460 compatibility
#define WORLD_NETHER
#define GBUF_BLOCK
#include "/program/surface/gbuffers_solid.vsh"
