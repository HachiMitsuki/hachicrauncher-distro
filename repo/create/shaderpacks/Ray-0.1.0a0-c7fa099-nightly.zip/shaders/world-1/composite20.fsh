#version 460 compatibility
#define WORLD_NETHER
#include "/program/post/taa.fsh"
