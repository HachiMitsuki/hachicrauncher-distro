#version 460 compatibility
#define WORLD_OVERWORLD
#include "/program/sky/vanilla_sky.vsh"
