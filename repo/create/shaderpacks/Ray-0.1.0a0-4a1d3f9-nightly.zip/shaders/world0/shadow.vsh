#version 460 compatibility
#define WORLD_OVERWORLD
#define PROGRAM_SHADOW_FALLBACK
#include "/program/light/shadow_terrain.vsh"
