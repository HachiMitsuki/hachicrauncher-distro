/*
 * ボリューメトリックライト / 高さフォグのレイマーチ (sky モジュール, composite1_a 専用)
 * light の sampleBlockLightVolume と surface の sampleShadowVolume を使うので light.glsl / surface.glsl の後に include する
 *
 * - 指数分布のステップ (Chocapic13 / Solas): 近くを細かく、遠くを粗く。ステップ内の位置をディザで揺らす
 * - 各サンプルで影マップ (光芒)、雲影 (FOG_CLOUD_SHADOWS)、floodfill (FOG_BLOCKLIGHT: 松明が霧を照らす)
 * - 区間ごとの解析積分 (Hillaire 2015): (1 - exp(-sigma dt)) で段差の無いエネルギー保存の和
 * - 影マップの範囲より遠い区間は解析積分で続ける (空と地形のフォグ量を一致させる)
 */
#ifndef SKY_VOLUMETRICS_GLSL
#define SKY_VOLUMETRICS_GLSL

//@include "/lib/settings.glsl"
//@include "/lib/common/color.glsl"
//@include "/lib/common/constants.glsl"
//@include "/lib/common/dimension.glsl"
//@include "/lib/common/math.glsl"
//@include "/lib/common/noise.glsl"
//@include "/lib/common/phase.glsl"
//@include "/lib/common/samplers.glsl"
//@include "/lib/common/shading_types.glsl"
//@include "/lib/common/shadow_space.glsl"
//@include "/lib/common/transforms.glsl"
//@include "/lib/common/uniforms.glsl"
//@include "/lib/common/voxel_space.glsl"
//@include "/lib/buffers/global_lights.glsl"
//@include "/lib/light/block_data.glsl"
//@include "/lib/light/blocklight.glsl"
//@include "/lib/light/light_select.glsl"
//@include "/lib/common/shadow_volume.glsl"
//@include "/lib/common/water.glsl"
//@include "/lib/sky/atmosphere.glsl"
//@include "/lib/sky/clouds.glsl"
//@include "/lib/sky/fog.glsl"
//@include "/lib/sky/fog_styles.glsl"
//@include "/lib/sky/sh.glsl"
//@include "/lib/sky/sky_color.glsl"

// 指数分布の強さ (大きいほど手前に集中)
const float VL_DISTRIBUTION = 3.0;
// 水中のマーチ範囲 (ブロック)。これより先は透過率がほぼ 0
const float VL_WATER_MAX_DIST = 48.0;
const float VL_MIN_TRANSMITTANCE = 0.005;
const float VL_WATER_COLUMN_DEFAULT = 4.0;
// 水の粒子の位相関数: Henyey-Greenstein の非対称度と、等方散乱を混ぜる割合 (海の粒子は前方に強く尖る, Petzold の g は 0.9 前後)
const float WATER_PHASE_G = 0.75;
const float WATER_PHASE_ISO = 0.3;
// 水中のブロックライトの位相関数の向きを求めるのに見るライトビンの光源の数
const int WATER_PHASE_MAX_LIGHTS = 8;
// 水中のブロックライトの内散乱の倍率 (空気のフォグの FOG_BLOCKLIGHT_STRENGTH に掛ける)。水は空気の霧より散乱が多く、光源の周りがよく光る
const float WATER_BLOCKLIGHT_SCATTER = 4.0;
// 洞窟内でも霧が完全な黒にならない最低限の明るさ
const float VL_MIN_AMBIENT_SCALE = 0.25;
// ネザーは溶岩がどこにでもあり、一様な霧がその光で一面に光って地形を覆う。霧が照らされる量だけ弱める
#ifdef WORLD_NETHER
    const float VL_BLOCKLIGHT_SCALE = 0.35;
#else
    const float VL_BLOCKLIGHT_SCALE = 1.0;
#endif

/*
 * VL 用の太陽影 (rgb = 色付き透過率)。inside = 影マップの範囲内か
 * VL_COLORED_SHADOWS が無ければ不透明の 1 フェッチだけ
 */
vec3 vlShadow(vec3 playerPos, out bool inside) {
#ifdef HAS_SUN_SHADOWS
    vec3 s = playerToShadowScreen(playerPos);
    inside = all(greaterThan(s, vec3(0.0))) && all(lessThan(s, vec3(1.0)));
    if (!inside) return vec3(1.0);
    #ifdef VL_COLORED_SHADOWS
        return sampleShadowVolume(playerPos);
    #else
        return vec3(step(s.z, texture(shadowtex1, s.xy).r));
    #endif
#else
    inside = false;
    return vec3(1.0);
#endif
}

/*
 * 点から光源方向に水面までの水の厚さ (ブロック)。shadowtex0 (半透明込み) は水面の深度を持つので、
 * 点の影空間の深度との差を view 空間の距離へ戻す (水中の光芒の減衰に使う)
 */
float vlWaterColumn(vec3 playerPos) {
#ifdef HAS_SUN_SHADOWS
    vec3 s = playerToShadowScreen(playerPos);
    if (any(lessThan(s, vec3(0.0))) || any(greaterThan(s, vec3(1.0)))) return VL_WATER_COLUMN_DEFAULT;
    float surface = texture(shadowtex0, s.xy).r;
    float dScreen = max(s.z - surface, 0.0);
    return dScreen * 2.0 / (SHADOW_DEPTH_SCALE * abs(shadowProjection[2][2]));
#else
    return VL_WATER_COLUMN_DEFAULT;
#endif
}

// 指数分布の区間境界 (x = 0..1 -> 0..maxDist)
float vlStepDistance(float x, float maxDist) {
    return maxDist * (exp2(VL_DISTRIBUTION * x) - 1.0) / (exp2(VL_DISTRIBUTION) - 1.0);
}

#ifdef VL_FAR
// 遠方区間の画面空間の光芒: 光の方向へ進める点の数と最大の距離 (ブロック)、深度の比較の余裕 (距離に対する割合)
const int VL_FAR_SAMPLES = 10;
const float VL_FAR_MAX_DIST = 256.0;
const float VL_FAR_DEPTH_BIAS = 0.02;
// 太陽が画面から外れていく視線では判定を弱める (cos: 100 度で使わない、60 度より近いと全部使う)
const float VL_FAR_FADE_COS_OFF = -0.17;
const float VL_FAR_FADE_COS_ON = 0.5;
// 画面の外へ出た点は端の画素の深度を外へ延ばして判定し、端から離れるほど信用しない (この幅 (UV) で 1 -> 0)
const float VL_FAR_OFFSCREEN_RANGE = 0.25;

/*
 * 影マップの範囲より遠い区間の太陽の見え方を画面空間で近似する (Mitchell 2007 の考え方を遠方区間だけに使う)
 * 遠方区間の中ほどの点から光の方向へ進み、画面に写した点より手前に地形があれば影とする。山・木・建物のシルエットから長い光芒が伸び、
 * 高い太陽の下の地形の上の空気 (光の方向へ進むと地形より手前を通る) は影にならない
 * 点が画面から出ても「見える」とはせず、端の画素で続けて判定する (太陽が画面の外で、手前の山の陰になる時も光が貫通しない)
 * dir: 視線 (player 空間), nearDist/farDist: 遠方区間, dither: 進める距離の揺らし (時間方向の積みで平均される)
 * 戻り値: x = 遠方区間の点の見え方、y = 影マップの範囲内の点の見え方 (影マップの外にある遮蔽物だけで下げる。範囲内の遮蔽は影マップが正確)
 */
vec2 vlFarScreenVisibility(vec3 dir, float nearDist, float farDist, float dither) {
    if (farDist <= nearDist) return vec2(1.0);
    float weight = smoothstep(VL_FAR_FADE_COS_OFF, VL_FAR_FADE_COS_ON, dot(dir, getShadowLightDir()));
    if (weight <= 0.0) return vec2(1.0);
    vec3 lightView = normalize(shadowLightPosition);
    vec3 origin = (mat3(gbufferModelView) * dir) * mix(nearDist, farDist, 0.5);
    vec2 texelMargin = vec2(0.5) / viewSize();
    vec2 blocked = vec2(0.0);
    for (int i = 0; i < VL_FAR_SAMPLES; i++) {
        float s = VL_FAR_MAX_DIST * sqr((float(i) + dither) / float(VL_FAR_SAMPLES));
        vec3 q = origin + lightView * s;
        if (q.z >= -0.05) break;
        vec2 p = projectAndDivide(gbufferProjection, q).xy * 0.5 + 0.5;
        vec2 edge = clamp(p, texelMargin, vec2(1.0) - texelMargin);
        float confidence = 1.0 - smoothstep(0.0, VL_FAR_OFFSCREEN_RANGE, length(p - edge));
        if (confidence <= 0.0) break;
        float depth = texelFetch(depthtex0, ivec2(edge * viewSize()), 0).r;
        if (depth >= 1.0 || isHandDepth(depth)) continue;
        float blocker = linearizeDepth(depth);
        if (blocker < -q.z * (1.0 - VL_FAR_DEPTH_BIAS)) {
            blocked.x = max(blocked.x, confidence);
            if (blocker >= nearDist) blocked.y = max(blocked.y, confidence);
            if (blocked.y >= 1.0) break;
        }
    }
    return 1.0 - weight * FS_VL_FAR * blocked;
}
#endif

// 光芒の洞窟の上限が 1 になるスカイライト。面の太陽 (SUN_SKYLIGHT_GATE) より広く、霧は面より目立たない
const float VL_CAVE_GATE = 3.0 / 15.0;

// 目と視線の先の面のスカイライトの大きいほうで光芒の太陽を抑える。入口の外や縦穴の底の明るい面を見ている時は残す
float vlCaveGate(float surfaceSkyLm) {
#if defined CAVE_LEAK_PREVENTION && defined HAS_SKYLIGHT
    return smoothstep(0.0, VL_CAVE_GATE, max(float(eyeBrightnessSmooth.y) / 240.0, surfaceSkyLm));
#else
    return 1.0;
#endif
}

/*
 * 空気中のフォグ (全ディメンション)。endDist: 地形 (空なら描画距離) までの距離
 * farVisibility: 影マップの範囲の外にある遮蔽物による太陽の見え方 (画面空間の光芒。無ければ 1)
 *   x = 範囲より遠い区間の点、y = 範囲内の点 (範囲内の点も、影マップに写らない遠い壁や山には遮られる)
 * aerial: 空中遠近を掛ける画素 (空以外)。空中遠近 (composite19) の内散乱は影を見ないので、視線上の影の分をここで引く
 * caveGate: 影マップの範囲内の太陽の上限 (vlCaveGate)。影マップに穴があっても、空の無い所の光芒に太陽を入れない
 * 戻り値: rgb = 内散乱 (空中遠近の影の分を引いた後), a = 透過率 (灰色)
 */
vec4 marchAirFog(vec3 dir, float endDist, float dither, vec2 farVisibility, float caveGate, bool aerial) {
    FogLighting fl = fogLightingSetup(dir);
    float outdoor = 1.0 - getCaveFactor();
#ifdef CAVE_LEAK_PREVENTION
    // 影マップの外では遮蔽が分からないので、目の位置の空の見え方と太陽の見え方で光芒を抑える
    float farSunVisibility = outdoor * farSunShade(dir) * farVisibility.x;
#else
    float farSunVisibility = farVisibility.x;
#endif

#if defined HAS_SKY
    FogMedium medium = fogMedium();
#elif defined WORLD_END
    float haze = END_FOG_EXTINCTION * END_FOG_DENSITY;
    float mist = 0.0;
#else
    float haze = netherFogExtinction();
    float mist = 0.0;
#endif

#ifdef HAS_SUN_SHADOWS
    float marchEnd = min(endDist, min(shadowDistance, fogRenderDistance()));
#else
    float marchEnd = min(endDist, fogRenderDistance());
#endif
#if defined HAS_SKY
    float invD = fogScenicInvD();
#endif

    vec3 scattering = vec3(0.0);
    float transmittance = 1.0;
#if defined HAS_SKY
    // 空中遠近の光学的深さの重み (写像した距離) と、そのうち日陰の分
    float aerialWeight = 0.0;
    float aerialShaded = 0.0;
#endif
    float tPrev = 0.0;
    for (int i = 0; i < VL_SAMPLES; i++) {
        float tNext = vlStepDistance(float(i + 1) / float(VL_SAMPLES), marchEnd);
        float dt = tNext - tPrev;
        float t = tPrev + dt * dither;
        tPrev = tNext;
        vec3 p = dir * t;

#if defined HAS_SKY
        vec2 density = fogDensityAt(p, medium);
        // 景色の成分は写像した距離で積む
        density.x *= fogScenicStretch(t, invD);
#else
        // ネザー・エンドは一様な霞に、ゆっくり漂う濃淡だけを付ける
        vec3 wp = p + cameraPosition + vec3(frameTimeCounter * 0.4, frameTimeCounter * 0.15, 0.0);
        vec2 density = vec2(haze * (0.6 + 0.8 * valueNoise3d(wp * 0.03)), 0.0);
    #ifdef WORLD_NETHER
        density.x *= netherFogNearFade(t);
    #endif
#endif
        float extinction = density.x + density.y;
        if (extinction < 1e-7) continue;

        bool inside;
        vec3 shadow = vlShadow(p, inside);
#if defined FOG_CLOUD_SHADOWS && defined HAS_SKY
        shadow *= getCloudShadow(p);
#endif
        float sunVisibility = inside ? farVisibility.y * caveGate : farSunVisibility;
        float skyVisibility = inside ? max(outdoor, luminance(shadow)) : outdoor;

        float ambientVisibility = max(skyVisibility, VL_MIN_AMBIENT_SCALE * MIN_AMBIENT / max(luminance(fl.ambient), 1e-6));
#if defined HAS_SKY
        // もやは空の色から影の分を引き (fogHazeRadiance)、霧は太陽と空の光で照らす
        float sunShadow = luminance(shadow) * sunVisibility;
        float aerialStep = fogScenicStretch(t, invD) * dt;
        aerialWeight += aerialStep;
        aerialShaded += aerialStep * (1.0 - saturate(sunShadow));
        vec3 hazeLight = fogHazeRadiance(fl, sunShadow, ambientVisibility);
        vec3 mistLight = (fl.light * shadow * (fl.phaseMist * sunVisibility * FOG_VL_STRENGTH) + fl.ambient * ambientVisibility) * FOG_ALBEDO;
        vec3 light = (density.x * hazeLight + density.y * mistLight) / extinction;
#else
        float phase = (density.x * fl.phaseHaze + density.y * fl.phaseMist) / extinction;
        vec3 light = fl.light * shadow * (phase * sunVisibility * optVlStrength);
        light += fl.ambient * ambientVisibility;
#endif
#ifdef FOG_BLOCKLIGHT
        light += sampleBlockLightVolume(p) * (FOG_BLOCKLIGHT_STRENGTH * VL_BLOCKLIGHT_SCALE * RCP_PI);
#endif

        float stepT = exp(-extinction * dt);
        scattering += transmittance * light * (1.0 - stepT);
        transmittance *= stepT;
        if (transmittance < VL_MIN_TRANSMITTANCE) break;
    }
    if (endDist > marchEnd && transmittance > VL_MIN_TRANSMITTANCE) {
        vec4 rest = fogAnalyticSegment(dir, marchEnd, endDist, fl, farSunVisibility, outdoor);
        scattering += transmittance * rest.rgb;
        transmittance *= rest.a;
#if defined HAS_SKY
        float restWeight = fogScenicDistance(endDist, invD) - fogScenicDistance(marchEnd, invD);
        aerialWeight += restWeight;
        aerialShaded += restWeight * (1.0 - saturate(farSunVisibility));
#endif
    }
#if defined HAS_SKY
    /*
     * 空中遠近は地形の色を同じ方位の空の色へ溶かすだけで影を見ない。夕日の方位の空の色は太陽の暈で明るく、
     * 森や壁の陰を通る視線でも奥が地平線の橙に光った。もやと同じく、日陰の区間の割合だけ影の中の値まで下げる
     * composite19 は空中遠近の後にこの透過率を掛けるので、引く分にも透過率を掛ける
     */
    if (aerial && aerialWeight > 0.0) {
        float outdoorScale = mix(AERIAL_OUTDOOR_MIN, 1.0, outdoor);
        vec3 aerialT = exp(-fogAerialExtinction(cameraPosition.y, cameraPosition.y + dir.y * endDist) * fogScenicDistance(endDist, invD) * outdoorScale);
        vec3 shadedLoss = max(fl.air * outdoor - fogHazeRadiance(fl, 0.0, outdoor), 0.0);
        scattering -= transmittance * shadedLoss * (1.0 - aerialT) * (aerialShaded / aerialWeight);
    }
#endif
    return vec4(scattering, transmittance);
}

// 水の粒子の位相関数 (前方に尖る)。太陽とブロックライトで同じ形を使う
float waterPhase(float cosTheta) {
    return mix(phaseHG(cosTheta, WATER_PHASE_G), PHASE_ISOTROPIC, WATER_PHASE_ISO);
}

#ifdef FOG_BLOCKLIGHT
/*
 * 水中のブロックライトの前方散乱の重み (等方散乱を 1 とした倍率)
 * floodfill の照度は遮蔽込みだが向きを持たないので、散乱点のライトビンの光源の向きから位相関数を照度で重み付け平均する
 * 視線の先にある光源ほど、カメラとの間の水が強く光る (水中の光源の周りのにじみ)
 * voxelPos: 散乱点 (voxel 空間), dir: 視線 (カメラ -> 散乱点)
 */
float waterBlockLightPhaseWeight(vec3 voxelPos, vec3 dir) {
    if (!isInVoxelVolume(voxelPos)) return 1.0;
    int bin = lightBinIndex(ivec3(voxelPos));
    uint n = min(lightBinCount(bin), uint(WATER_PHASE_MAX_LIGHTS));
    float sumE = 0.0;
    float sumP = 0.0;
    for (uint k = 0u; k < n; k++) {
        LightInstance L = globalLights.lights[lightBinEntry(bin, k)];
        vec3 toL = L.posRadius.xyz - voxelPos;
        float d = length(toL);
        if (d >= L.posRadius.w) continue;
        float e = luminance(L.colorSize.rgb) * lightFalloff(d, L.posRadius.w);
        // 光は光源 -> 散乱点へ進み、カメラ (-dir) へ曲がる。その角の cos は dot(toL, dir) / d
        sumP += e * waterPhase(dot(toL, dir) / max(d, 1e-3));
        sumE += e;
    }
    return sumE > 0.0 ? sumP / (sumE * PHASE_ISOTROPIC) : 1.0;
}
#endif

/*
 * 水中 (カメラが水の中): 水面からの光の減衰込みの光芒。透過率は composite19 が距離から解析的に掛けるので内散乱だけ返す
 * ステップは空気と同じ指数分布 (近くを細かく)。等間隔では 1 歩が 3-6 ブロックになり、近くの光源の周りの光り方が粗かった
 */
vec3 marchWaterFog(vec3 dir, float endDist, float dither) {
    LightSample celestial = getCelestialLight();
    float phase = waterPhase(dot(dir, celestial.direction));
    vec3 skyUp = shEvalIrradiance(vec3(0.0, 1.0, 0.0));
    vec3 extinction = waterExtinction();
    vec3 scatter = waterScattering();
    float lightY = max(celestial.direction.y, 0.1);

    float marchEnd = min(endDist, VL_WATER_MAX_DIST);
    vec3 result = vec3(0.0);
    vec3 transmittance = vec3(1.0);
    float tPrev = 0.0;
    for (int i = 0; i < VL_SAMPLES; i++) {
        float tNext = vlStepDistance(float(i + 1) / float(VL_SAMPLES), marchEnd);
        float dt = tNext - tPrev;
        float t = tPrev + dt * dither;
        tPrev = tNext;
        vec3 p = dir * t;
        bool inside;
        vec3 shadow = vlShadow(p, inside);
        float column = vlWaterColumn(p);
        vec3 lightT = exp(-extinction * column);
        // 空の光は水面からの深さ (光源方向の水の厚さ x 光源の高さ) だけ減衰する
        vec3 ambientT = exp(-extinction * column * lightY);
        vec3 light = celestial.irradiance * shadow * lightT * phase * optVlStrength + skyUp * ambientT * (0.5 * RCP_PI);
#ifdef FOG_BLOCKLIGHT
        vec3 blockE = sampleBlockLightVolume(p);
        if (maxOf(blockE) > 1e-5) {
            light += blockE * (FOG_BLOCKLIGHT_STRENGTH * WATER_BLOCKLIGHT_SCATTER * RCP_PI)
                * waterBlockLightPhaseWeight(playerToVoxel(p), dir);
        }
#endif
        vec3 stepT = exp(-extinction * dt);
        result += transmittance * light * scatter * (1.0 - stepT) / extinction;
        transmittance *= stepT;
    }
    return result;
}

#endif
