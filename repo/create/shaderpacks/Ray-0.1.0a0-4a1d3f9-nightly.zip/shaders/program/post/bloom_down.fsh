/*
 * composite23: ブルームの縮小タイル生成 (colortex0 のミップ -> colortex14 にタイル配置, lib/post/bloom.glsl)
 * 各レベルは 1 つ上のミップから Jimenez 2014 (COD: AW) の 13 タップで縮小する
 * ハードウェアのミップ (箱フィルタ) を直接使うよりエイリアスとちらつきが少ない
 * 最初の縮小の輝度の重み付け (Karis average) は使わない。元の colortex0 は TAA で時間方向に均した後なので 1 フレームだけの
 * ホタルはほとんど残らず (物陰から出た所や動いている間は一部残る)、重みを掛けると照り返しの小さな明るい点のすぐ周りの滲みだけが削れる
 * 閾値は掛けない (エネルギーを捨てない物理寄りのブルーム。強さは final の混合率で決まる)
 * post モジュール (lib/post)
 */
//@include "/lib/common/common.glsl"
//@include "/lib/post/post_internal.glsl"
//@include "/lib/post/local_tonemap.glsl"
// BEGIN GENERATED includes (tools/gen_includes.py)
#include "/lib/settings/look.glsl"
#include "/lib/settings/light.glsl"
#include "/lib/settings/surface.glsl"
#include "/lib/settings/sky.glsl"
#include "/lib/settings/post.glsl"
#include "/lib/settings/internal.glsl"
#include "/lib/settings/bool_refs.glsl"
#include "/lib/settings.glsl"
#include "/lib/common/dimension.glsl"
#include "/lib/common/constants.glsl"
#include "/lib/common/uniforms.glsl"
#include "/lib/common/samplers.glsl"
#include "/lib/common/math.glsl"
#include "/lib/common/shading_types.glsl"
#include "/lib/common/common.glsl"
#include "/lib/common/jitter.glsl"
#include "/lib/common/transforms.glsl"
#include "/lib/post/velocity.glsl"
#include "/lib/common/color.glsl"
#include "/lib/common/look_presets.glsl"
#include "/lib/post/tonemap.glsl"
#include "/lib/post/post.glsl"
#include "/lib/post/post_constants.glsl"
#include "/lib/post/lens_presets.glsl"
#include "/lib/post/sampling.glsl"
#include "/lib/post/exposure.glsl"
#include "/lib/buffers/frame_data.glsl"
#include "/lib/post/camera.glsl"
#include "/lib/post/grading.glsl"
#include "/lib/buffers/images.glsl"
#include "/lib/buffers/slots.glsl"
#include "/lib/post/bloom.glsl"
#include "/lib/common/noise.glsl"
#include "/lib/post/lens_optics.glsl"
#include "/lib/common/celestial_shape.glsl"
#include "/lib/post/lens_ghosts.glsl"
#include "/lib/post/lens_flare.glsl"
#include "/lib/post/lens.glsl"
#include "/lib/post/post_internal.glsl"
#include "/lib/post/local_tonemap.glsl"
// END GENERATED includes

const bool colortex0MipmapEnabled = true;

in vec2 texcoord;

/* RENDERTARGETS: 14 */
layout(location = 0) out vec4 outBloom;

/*
 * rgb = ブルームの元の色、a = そのうち溶岩の発光の輝度 (final が溶岩の滲みを溶岩と同じ色を保つトーンマップに寄せる)
 * colortex0.a < 0 は溶岩の発光の割合 (composite19 -> TAA)。ミップは範囲の平均の割合になる
 */
vec4 fetchSource(vec2 uv, float lod) {
    vec4 s = textureLod(colortex0, clamp(uv, vec2(0.0), vec2(1.0)), lod);
    vec3 c = sanitizeColor(s.rgb);
    float lava = clamp(-s.a, 0.0, 1.0);
    return vec4(c * (1.0 + (LAVA_BLOOM_GAIN - 1.0) * lava), luminance(c) * LAVA_BLOOM_GAIN * lava);
}

void main() {
    ivec4 rect;
#if LOCAL_TONEMAP > 0
    if (isInLocalTonemapTile(ivec2(gl_FragCoord.xy), rect)) {
        outBloom = vec4(sampleLocalTonemapSource(colortex0, (gl_FragCoord.xy - vec2(rect.xy)) / vec2(rect.zw)), 0.0, 0.0);
        return;
    }
#endif
    int level = bloomTileLevelAt(ivec2(gl_FragCoord.xy), rect);
    if (level == 0) {
        outBloom = vec4(0.0);
        return;
    }

    vec2 uv = (gl_FragCoord.xy - vec2(rect.xy)) / vec2(rect.zw);
    float lod = float(level - 1);
    // 1 段上のミップの 1 テクセル (この段の半テクセル)
    vec2 t = exp2(lod) * texelSize();

    vec4 a = fetchSource(uv + t * vec2(-2.0, 2.0), lod);
    vec4 b = fetchSource(uv + t * vec2(0.0, 2.0), lod);
    vec4 c = fetchSource(uv + t * vec2(2.0, 2.0), lod);
    vec4 d = fetchSource(uv + t * vec2(-2.0, 0.0), lod);
    vec4 e = fetchSource(uv, lod);
    vec4 f = fetchSource(uv + t * vec2(2.0, 0.0), lod);
    vec4 g = fetchSource(uv + t * vec2(-2.0, -2.0), lod);
    vec4 h = fetchSource(uv + t * vec2(0.0, -2.0), lod);
    vec4 i = fetchSource(uv + t * vec2(2.0, -2.0), lod);
    vec4 j = fetchSource(uv + t * vec2(-1.0, 1.0), lod);
    vec4 k = fetchSource(uv + t * vec2(1.0, 1.0), lod);
    vec4 l = fetchSource(uv + t * vec2(-1.0, -1.0), lod);
    vec4 m = fetchSource(uv + t * vec2(1.0, -1.0), lod);

    outBloom = e * 0.125 + (a + c + g + i) * 0.03125 + (b + d + f + h) * 0.0625 + (j + k + l + m) * 0.125;
}
