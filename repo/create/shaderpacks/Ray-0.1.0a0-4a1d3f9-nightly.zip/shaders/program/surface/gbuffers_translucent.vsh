/*
 * 半透明ジオメトリ共通の頂点シェーダー (水・色ガラス・手持ちの半透明・半透明パーティクル・半透明エンティティ)
 * 呼び出し元が GBUF_WATER / GBUF_HAND_WATER / GBUF_PARTICLES_TRANSLUCENT / GBUF_ENTITIES_TRANSLUCENT / GBUF_BLOCK_TRANSLUCENT を define する
 * surface モジュール (lib/surface)
 */
#ifdef GBUF_ENTITIES_TRANSLUCENT
    // 半透明で描かれる光源エンティティ (アレイ等) も画面内で登録する (lib/buffers/images.glsl)
    // 蓄積表に書く SSBO_LIGHT_BINS_WRITE は lib/buffers/light_bins.glsl が定義する
    #define IMG_VOXEL_EMIT
#endif
#ifdef GBUF_PARTICLES_TRANSLUCENT
    // 光る粒の位置と色を花火の光に溜める (FIREWORK_LIGHT、lib/buffers/firework_light.glsl)
    #define SSBO_FIREWORK_LIGHT_WRITE
#endif
//@include "/lib/common/common.glsl"
//@include "/lib/common/constants.glsl"
//@include "/lib/common/jitter.glsl"
//@include "/lib/ids/id_decode.glsl"
//@include "/lib/surface/surface.glsl"
#ifdef GBUF_ENTITIES_TRANSLUCENT
    //@include "/lib/light/light.glsl"
#endif
#if defined GBUF_PARTICLES_TRANSLUCENT && (defined FIREWORK_GLOW || defined FIREWORK_LIGHT)
    //@include "/lib/surface/particle_glow.glsl"
#endif
#if defined GBUF_PARTICLES_TRANSLUCENT && defined FIREWORK_LIGHT
    //@include "/lib/light/firework_light.glsl"
#endif
// BEGIN GENERATED includes (tools/gen_includes.py)
#include "/lib/settings/look.glsl"
#include "/lib/settings/light.glsl"
#include "/lib/settings/surface.glsl"
#include "/lib/settings/sky.glsl"
#include "/lib/settings/post.glsl"
#include "/lib/settings/internal.glsl"
#include "/lib/settings/bool_refs.glsl"
#include "/lib/settings.glsl"
#include "/lib/common/dimension.glsl"
#include "/lib/common/constants.glsl"
#include "/lib/common/uniforms.glsl"
#include "/lib/common/samplers.glsl"
#include "/lib/common/math.glsl"
#include "/lib/common/shading_types.glsl"
#include "/lib/common/common.glsl"
#include "/lib/common/jitter.glsl"
#include "/lib/ids/block_ids.glsl"
#include "/lib/ids/entity_ids.glsl"
#include "/lib/ids/light_ids.glsl"
#include "/lib/ids/material_ids.glsl"
#include "/lib/ids/id_decode.glsl"
#include "/lib/common/color.glsl"
#include "/lib/common/encoding.glsl"
#include "/lib/common/gbuffer.glsl"
#include "/lib/surface/material.glsl"
#include "/lib/surface/brdf.glsl"
#include "/lib/common/frame_offset.glsl"
#include "/lib/common/look_presets.glsl"
#include "/lib/common/voxel_space.glsl"
#include "/lib/buffers/images.glsl"
#include "/lib/buffers/slots.glsl"
#include "/lib/surface/gi.glsl"
#include "/lib/common/noise.glsl"
#include "/lib/common/transforms.glsl"
#include "/lib/buffers/frame_data.glsl"
#include "/lib/common/water_waves.glsl"
#include "/lib/common/water_glitter.glsl"
#include "/lib/common/water_lod.glsl"
#include "/lib/common/water_normal.glsl"
#include "/lib/common/water.glsl"
#include "/lib/common/shadow_space.glsl"
#include "/lib/common/shadow_volume.glsl"
#include "/lib/surface/sun_shadow.glsl"
#include "/lib/surface/waving.glsl"
#include "/lib/surface/surface.glsl"
#ifdef GBUF_ENTITIES_TRANSLUCENT
    #include "/lib/buffers/light_bins.glsl"
    #include "/lib/light/light_bins.glsl"
    #include "/lib/buffers/block_data.glsl"
    #include "/lib/light/light_def.glsl"
    #include "/lib/light/light_table_data.glsl"
    #include "/lib/light/light_table.glsl"
    #include "/lib/light/block_data.glsl"
    #include "/lib/light/voxel_read.glsl"
    #include "/lib/light/voxel.glsl"
    #include "/lib/light/floodfill.glsl"
    #include "/lib/buffers/entity_tris.glsl"
    #include "/lib/light/entity_tri.glsl"
    #include "/lib/light/trace.glsl"
    #include "/lib/buffers/global_lights.glsl"
    #include "/lib/light/light_select.glsl"
    #include "/lib/settings/capabilities.glsl"
    #include "/lib/light/hand_pose.glsl"
    #include "/lib/light/entity_light.glsl"
    #include "/lib/light/hand_light.glsl"
    #include "/lib/light/blocklight.glsl"
    #include "/lib/light/light.glsl"
#endif
#if defined GBUF_PARTICLES_TRANSLUCENT && (defined FIREWORK_GLOW || defined FIREWORK_LIGHT)
    #include "/lib/common/exposure.glsl"
    #include "/lib/surface/particle_glow.glsl"
#endif
#if defined GBUF_PARTICLES_TRANSLUCENT && defined FIREWORK_LIGHT
    #include "/lib/common/phase.glsl"
    #include "/lib/buffers/firework_light.glsl"
    #include "/lib/light/firework_light.glsl"
#endif
// END GENERATED includes

#ifdef GBUF_WATER
    in vec2 mc_Entity;
    in vec4 at_midBlock;
#endif
#if defined GBUF_ENTITIES_TRANSLUCENT || defined GBUF_BLOCK_TRANSLUCENT
    in vec2 mc_midTexCoord;
#endif
in vec4 at_tangent;

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 viewPos;
out vec3 normalPlayer;
out vec4 tangentPlayer;
// 面の UV の中心と半幅 (エンティティ・ブロックエンティティの自動法線が隣の面の絵を読まないように。gbuffers_solid.vsh と同じ)
out vec2 tileMid;
out vec2 tileHalf;
flat out int blockId;
#if defined GBUF_PARTICLES_TRANSLUCENT && defined FIREWORK_GLOW
// 光る粒の四角の角 (-1..1) と瞬きの倍率 (0 = 光らない粒)。lib/surface/particle_glow.glsl
out vec2 glowCorner;
out float glowGain;
#endif

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = saturate(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 1.0 / LIGHTMAP_TEXELS) * LIGHTMAP_TEXELS / LIGHTMAP_RANGE);
    glcolor = gl_Color;
    normalPlayer = viewToPlayerDir(normalize(gl_NormalMatrix * gl_Normal));
    tangentPlayer = vec4(viewToPlayerDir(normalize(gl_NormalMatrix * at_tangent.xyz)), at_tangent.w);
#ifdef GBUF_WATER
    blockId = terrainBlockId(int(round(mc_Entity.x)));
#else
    blockId = 0;
#endif
#if defined GBUF_ENTITIES_TRANSLUCENT || defined GBUF_BLOCK_TRANSLUCENT
    tileMid = mc_midTexCoord;
    tileHalf = abs(texcoord - mc_midTexCoord);
#else
    tileMid = vec2(0.5);
    tileHalf = vec2(0.5);
#endif
    viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
#if defined GBUF_PARTICLES_TRANSLUCENT && defined FIREWORK_GLOW
    glowCorner = particleCorner(gl_VertexID);
    glowGain = 0.0;
#endif
#if defined GBUF_PARTICLES_TRANSLUCENT && (defined FIREWORK_GLOW || defined FIREWORK_LIGHT)
    if (isGlowingParticle(gl_MultiTexCoord1.xy)) {
    #ifdef FIREWORK_LIGHT
        if ((gl_VertexID & 3) == 0) fireworkAccAdd(viewToPlayer(viewPos), srgbToLinear(gl_Color.rgb), gl_Color.a);
    #endif
    #ifdef FIREWORK_GLOW
        viewPos = expandParticleCorner(viewPos, glowCorner);
        glowGain = max(particleTwinkle(viewToPlayer(viewPos) + cameraPosition), 1e-3);
    #endif
    }
#endif
#ifdef GBUF_ENTITIES_TRANSLUCENT
    if ((gl_VertexID & 3) == 0) injectEntityLight(viewToPlayer(viewPos), entityId, currentRenderedItemId, entityColor);
#endif
    gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);
    applyTaaJitter(gl_Position);
}
