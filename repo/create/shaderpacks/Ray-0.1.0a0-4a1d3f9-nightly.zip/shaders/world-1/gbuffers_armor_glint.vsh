#version 460 compatibility
#define WORLD_NETHER
#define GBUF_ARMOR_GLINT
#include "/program/surface/gbuffers_overlay.vsh"
